
export enum JobType {
  EMPLOYEE = 'Karyawan',
  ENTREPRENEUR = 'Wirausaha'
}

export enum MaritalStatus {
  SINGLE = 'Belum Menikah',
  MARRIED = 'Sudah Menikah'
}

export interface ApplicantData {
  fullName: string;
  ktpNumber: string;
  npwpNumber: string;
  btnAccountNumber: string;
  pob: string;
  dob: string;
  address: string;
  phone: string;
  jobType: JobType;
  jobTitle: string;
  companyName: string;
  monthlyIncome: number;
}

export interface SpouseData {
  fullName: string;
  pob: string;
  dob: string;
  job: string;
  address: string;
  isWorking: boolean;
  ktpNumber: string;
}

export interface PropertyData {
  projectName: string;
  houseAddress: string;
  houseSize: number;
  landSize: number;
  kavlingNumber: string;
  nibNumber: string;
  certificateDate: string;
  pbgNumber: string;
  pbgDate: string;
  price: number;
  downPayment: number;
  paidDP: number;
  remainingDP: number;
  sbumAmount: number;
  kprPlafon: number;
  kprTerm: number;
  electricity: string;
  water: string;
  sprNumber: string;
  buildingYear: string;
}

export interface AppState {
  applicant: ApplicantData;
  maritalStatus: MaritalStatus;
  spouse?: SpouseData;
  property: PropertyData;
  dateOfDocument: string;
  documentType: 'data-entry' | 'ajb-bank';
}

export interface HistoryEntry {
  id: string;
  clientName: string;
  unitInfo: string;
  savedAt: string;
  data: AppState;
}
