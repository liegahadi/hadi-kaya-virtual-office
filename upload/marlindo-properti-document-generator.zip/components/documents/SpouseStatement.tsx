
import React from 'react';
import { AppState } from '../../types';
import { formatLongDate } from '../../utils/formatters';
import { DocumentLayout } from '../DocumentLayout';

export const SpouseStatement: React.FC<{ data: AppState }> = ({ data }) => {
  const { applicant, spouse, dateOfDocument } = data;

  if (!spouse || spouse.isWorking) return null;

  return (
    <DocumentLayout>
      <div className="text-center mb-10 mt-10">
        <h2 className="text-xl font-bold underline">SURAT PERNYATAAN TIDAK BEKERJA / TIDAK BERPENGHASILAN</h2>
      </div>

      <p className="mb-4">Saya yang bertanda tangan di bawah ini:</p>
      <table className="w-full mb-8 ml-4">
        <tbody>
          <tr><td className="w-48">Nama</td><td>: {spouse.fullName}</td></tr>
          <tr><td>Tempat/Tgl Lahir</td><td>: {spouse.pob}, {formatLongDate(spouse.dob)}</td></tr>
          <tr><td>Alamat</td><td>: {spouse.address}</td></tr>
          <tr><td>Hubungan Keluarga</td><td>: Istri / Suami dari {applicant.fullName}</td></tr>
        </tbody>
      </table>

      <p className="mb-6 text-justify leading-relaxed">
        Dengan ini menyatakan dengan sesungguhnya bahwa sampai dengan saat ini saya <strong>TIDAK BEKERJA</strong> dan <strong>TIDAK MEMILIKI PENGHASILAN TETAP</strong> maupun tidak tetap.
      </p>

      <p className="mb-6 text-justify leading-relaxed">
        Surat pernyataan ini saya buat dengan penuh kesadaran dan tanpa paksaan dari pihak manapun, guna melengkapi persyaratan administrasi pengajuan KPR Bersubsidi atas nama pasangan saya tersebut di atas pada Bank BTN.
      </p>

      <p className="mb-10 text-justify leading-relaxed">
        Demikian pernyataan ini saya buat, apabila di kemudian hari ternyata pernyataan ini tidak benar, maka saya bersedia menerima sanksi sesuai dengan ketentuan yang berlaku.
      </p>

      <div className="flex justify-end mr-10 mt-20">
        <div className="text-center">
          <p>Pangkalpinang, {formatLongDate(dateOfDocument)}</p>
          <p className="mt-2">Yang menyatakan,</p>
          <div className="h-24 flex items-center justify-center italic text-gray-400">Materai Rp. 10.000</div>
          <p className="font-bold underline">{spouse.fullName}</p>
        </div>
      </div>
    </DocumentLayout>
  );
};
