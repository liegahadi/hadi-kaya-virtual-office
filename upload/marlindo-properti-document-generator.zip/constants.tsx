
export const COMPANY_INFO = {
  name: 'PT. Marlindo Bangun Persada',
  city: 'Pangkalpinang',
  director: 'Andrian Bong',
  btnAccount: '00209 0130 000 3316',
  bankName: 'BTN Cabang Pangkalpinang',
  bankAddress: 'Jl. Jenderal Sudirman No. 10, Pangkalpinang'
};

export const DEFAULT_PROPERTY = {
  projectName: 'ANJAYO 16',
  houseAddress: 'Jl. Kelompok, Jerambah Gantung, Kerabut',
  houseSize: 36,
  landSize: 84,
  kavlingNumber: '',
  nibNumber: '',
  certificateDate: '',
  pbgNumber: 'SK-PBG-197106-24112023-001',
  pbgDate: '2023-11-24',
  price: 173000000,
  downPayment: 1730000,
  sbumAmount: 4000000,
  kprPlafon: 167270000,
  kprTerm: 20,
  electricity: '1300 Watt',
  water: 'Sumur Bor Besar',
  sprNumber: '60',
  buildingYear: new Date().getFullYear().toString()
};
