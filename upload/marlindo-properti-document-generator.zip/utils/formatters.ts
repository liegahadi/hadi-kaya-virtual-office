
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0
  }).format(amount).replace("Rp", "Rp.");
};

export const formatLongDate = (dateString: string): string => {
  if (!dateString) return '..........................';
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(date);
};

export const numberToWords = (n: number): string => {
  const words = ["", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas"];
  let res = "";
  if (n < 12) res = words[n];
  else if (n < 20) res = numberToWords(n - 10) + " Belas";
  else if (n < 100) res = numberToWords(Math.floor(n / 10)) + " Puluh " + numberToWords(n % 10);
  else if (n < 200) res = "Seratus " + numberToWords(n - 100);
  else if (n < 1000) res = numberToWords(Math.floor(n / 100)) + " Ratus " + numberToWords(n % 100);
  else if (n < 2000) res = "Seribu " + numberToWords(n - 1000);
  else if (n < 1000000) res = numberToWords(Math.floor(n / 1000)) + " Ribu " + numberToWords(n % 1000);
  else if (n < 1000000000) res = numberToWords(Math.floor(n / 1000000)) + " Juta " + numberToWords(n % 1000000);
  
  return res.trim().replace(/\s+/g, ' ');
};

export const getMonthRomawi = (dateString: string): string => {
  const date = new Date(dateString);
  const romawi = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
  return romawi[date.getMonth()];
};
