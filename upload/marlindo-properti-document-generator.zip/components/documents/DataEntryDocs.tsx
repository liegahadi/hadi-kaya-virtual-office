
import React from 'react';
import { AppState, JobType, MaritalStatus } from '../../types';
import { COMPANY_INFO } from '../../constants';
import { formatCurrency, formatLongDate, numberToWords, getMonthRomawi } from '../../utils/formatters';

const styles = {
  page: "a4-container text-[11.5pt] leading-snug text-black",
  times: { fontFamily: "'Times New Roman', Times, serif" },
  headerRight: "text-right text-[10pt] mb-1 font-bold",
  docTitle: "text-center font-bold underline text-[12pt] uppercase mb-1",
  docSubTitle: "text-center font-bold text-[12pt] uppercase mb-4",
  tableLabel: "w-[180px] align-top",
  tableColon: "w-[15px] align-top",
  signatureArea: "mt-8 flex justify-between",
  signatureBox: "text-center min-w-[220px]",
  badge: "border border-black px-4 py-1 italic absolute top-10 right-10 text-[10pt]"
};

const PageWrapper: React.FC<{ children: React.ReactNode, narrow?: boolean }> = ({ children, narrow }) => (
  <div 
    className={`${styles.page} page-break relative`} 
    style={{
      ...styles.times,
      paddingTop: narrow ? '0.2in' : '20mm',
      paddingBottom: narrow ? '0.2in' : '20mm'
    }}
  >
    {children}
  </div>
);

// 1. SPR (Anjayo 16)
export const SPR_Official: React.FC<{ data: AppState }> = ({ data }) => {
  const docDate = new Date(data.dateOfDocument);
  const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  
  return (
    <PageWrapper narrow>
      <div className="text-center mb-0">
        <h1 className="text-3xl font-bold">{data.property.projectName}</h1>
        <p className="text-[11pt] font-bold">KANTOR PEMASARAN JL. FATMAWATI ( KAMPAK)</p>
        <div className="border-b-2 border-black w-full my-1"></div>
        <div className="font-bold underline text-[12pt]">FORM PEMESANAN</div>
        <p className="text-[10pt]">NO. {data.property.sprNumber} /SPR/{getMonthRomawi(data.dateOfDocument)} /SPR – AJR/2026</p>
      </div>
      
      <p className="mt-2 mb-1">Saya yang bertanda tangan dibawah ini :</p>
      <table className="mb-2 text-[11pt]">
        <tbody>
          <tr><td className="w-[160px]">Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName || '..........................'}</td></tr>
          <tr><td>Nomor KTP</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber || '..........................'}</td></tr>
          <tr><td>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle || '..........................'}</td></tr>
          <tr><td>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address || '..........................'}</td></tr>
          <tr><td>No.Telp/HP Pemohon</td><td className={styles.tableColon}>:</td><td>{data.applicant.phone || '..........................'}</td></tr>
        </tbody>
      </table>
      
      <p className="text-justify text-[11pt] mb-2 leading-tight">
        Setelah saya mendapatakan penjelasan dan melihat ke lokasi Pembangunan Perumahan “ {data.property.projectName} “ di 
        Lokasi {data.property.houseAddress}, PANGKALPINANG dengan ini saya memutuskan untuk 
        melakukan pembelian/pemesanan Rumah sbb :
      </p>
      
      <div className="font-bold text-[11pt] mb-1 uppercase">DATA –DATA RUMAH YANG SAYA PESAN :</div>
      <table className="text-[11pt] leading-none mb-2 w-full">
        <tbody>
          <tr><td className="w-8">1.</td><td className="w-48">Cara Pembayaran</td><td>: KPR</td></tr>
          <tr><td>2.</td><td>Harga Pembelian</td><td>: {formatCurrency(data.property.price)}</td></tr>
          <tr><td>3.</td><td>Uang Muka</td><td>: {formatCurrency(data.property.downPayment)}</td></tr>
          <tr><td>4.</td><td>SBUM</td><td>: {formatCurrency(data.property.sbumAmount)}</td></tr>
          <tr><td>5.</td><td>Plafon KPR</td><td>: {formatCurrency(data.property.kprPlafon)}</td></tr>
          <tr><td>6.</td><td>Jangka Waktu</td><td>: {data.property.kprTerm} Tahun</td></tr>
          <tr><td>7.</td><td>No. Kavling Rumah</td><td>: {data.property.kavlingNumber || '........'} ( Site Plan terlampir )</td></tr>
          <tr><td>8.</td><td>Type</td><td>: 36/ {data.property.landSize} (Luas Tanah) M2</td></tr>
          <tr><td>9.</td><td>No. Sertifikat</td><td>: {data.property.nibNumber || '...................'}</td></tr>
          <tr><td>10.</td><td>No. PBG</td><td>: {data.property.pbgNumber} Tgl Terbit {formatLongDate(data.property.pbgDate)}</td></tr>
          <tr><td>11.</td><td>Listrik</td><td>: {data.property.electricity}</td></tr>
          <tr><td>12.</td><td>Air</td><td>: {data.property.water}</td></tr>
          <tr><td>13.</td><td>Tahun Bangunan</td><td>: {data.property.buildingYear}</td></tr>
        </tbody>
      </table>

      <p className="text-[10pt] mb-1">Demikianlah pesanan ini kami sampaikan, atas perhatian, bantuan dan kerja sama yang baik, kami ucapkan terima kasih.</p>
      
      <div className="text-[8.5pt] leading-[1.1] space-y-0">
        <p className="font-bold underline">Catatan :</p>
        <p>1. Apabila hasil BI Cheking saya tidak sesuai dengan pernyataan yang telah saya buat sebelumnya maka saya bersedia menerima semua konsekuensinya.</p>
        <p>2. Harga tersebut diatas termasuk :</p>
        <div className="pl-4">
          <p>- Biaya IMB dari Pemerintah Kota Pangkalpinang.</p>
          <p>- Biaya Pemecahan Sertifikat Induk ( SHGB )</p>
          <p>- PLN 1300 Watt dan air bor/PDAM</p>
          <p>- PPN 1% dari harga jual</p>
          <p>- BPHTB, AJB/balik nama dan biaya KPR</p>
        </div>
        <p>3. Dp harus lunas dalam waktu 1 minggu terhitung sejak booking fee</p>
        <p>4. Berkas lengkap dalam 7 hari kerja dan wajib membuat buku tabungan KPR BTN</p>
        <p>5. Booking Fee/DP tidak bisa di kembalikan dengan alasan apapun termasuk jika calon nasabah memberikan keterangan tidak sesuai dalam form wawancara sehingga ditolak oleh pihak bank.</p>
        <p>6. SBUM (bantuan uang muka) adalah sebagai pengganti DP atau biaya proses lainnya kepada DEVELOPER dan pencairannya saya setuju dicairkan atau di pindah bukukan ke rekening {COMPANY_INFO.name} dengan Rek Bank BTN NO. {COMPANY_INFO.btnAccount}</p>
        <p>7. Harga diatas belum termasuk saldo mengendap yang ditentukan oleh pihak BANK.</p>
        <p>8. Apabila terjadi penurunan plafond dari pihak BANK, maka calon nasabah di wajibkan membayar kekurangan plafond tersebut.</p>
        <p>9. Jika dalam tempo 7 hari DP belum lunas atau berkas tidak dilengkapi terhitung sejak tgl boooking fee maka, harga promo tidak berlaku lagi dan akan dikembalikan ke harga normal.</p>
        <p>10. Form wawancara wajib di isi sesuai dengan data yang sebenar benar nya.</p>
        <p>11. Jika berkas tidak lengkap dalam jangka waktu 14 hari kerja , maka saya dianggap mengundurkan diri dan menerima semua konsekuensinya.</p>
        <p>12. Informasi & berkas yang diserahkan kepada pihak <strong>{COMPANY_INFO.name.toUpperCase()}</strong> kebenarannya , sepenuhnya merupakan tanggung jawab Pemesan/ Debitur</p>
        <p>13. Harga sewaktu-waktu bisa berubah sesuai dengan pemberitahuan dari Bank.</p>
      </div>

      <div className="flex justify-between mt-4 text-[11pt]">
        <div>
          <p>Pangkalpinang, {docDate.getDate()} {monthNames[docDate.getMonth()]} {docDate.getFullYear()}</p>
          <p>Pemesan,</p>
          <div className="h-16 flex items-center italic text-gray-400 text-[9pt]">
            <div className="border border-gray-300 p-2 uppercase">Materai 10.000</div>
          </div>
          <p className="font-bold underline uppercase">{data.applicant.fullName || '..........................'}</p>
        </div>
        <div className="text-center">
          <p className="invisible">.</p>
          <p className="font-bold uppercase tracking-tight">BAG.PENJUALAN</p>
          <p className="font-bold uppercase tracking-tight">PERUMAHAN {data.property.projectName} RESIDENCE</p>
          <div className="h-16"></div>
          <p className="font-bold underline">{COMPANY_INFO.director}</p>
        </div>
      </div>
    </PageWrapper>
  );
};

// 2. Surat Pernyataan Penghasilan (Tetap)
export const IncomeStatementFixed: React.FC<{ data: AppState }> = ({ data }) => {
  if (data.applicant.jobType !== JobType.EMPLOYEE) return null;
  return (
    <PageWrapper>
      <div className={styles.headerRight}>(MBR Berpenghasilantetap)</div>
      <div className={styles.docTitle}>SURAT PERNYATAAN PENGHASILAN</div>
      <p className="mt-8 mb-4">Yang bertandatangan di bawah ini:</p>
      <table className="mb-6">
        <tbody>
          <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
          <tr><td className={styles.tableLabel}>Tempat/tgl lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
          <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
          <tr><td className={styles.tableLabel}>No. KTP/Passport</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
          <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
        </tbody>
      </table>
      <p className="text-justify mb-6 leading-relaxed">
        Menyatakan dengan sesungguhnya bahwa sampai saat surat pernyataan ini ditandatangani, saya menyatakan bahwa 
        jumlah gaji/upah pokok saya adalah sebesar Rp. .................................. ( ...........................) per bulan.
      </p>
      <p className="text-justify mb-8 leading-relaxed">
        Demikian surat pernyataan ini saya buat dengan sebenarnya tanpa paksaan dari pihak manapun dan apabila di 
        kemudian hari pernyataan saya ini tidak benar, saya bersedia mengembalikan seluruh subsidi yang saya terima.
      </p>
      <div className="text-right mb-12">{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</div>
      <div className={styles.signatureArea}>
        <div className={styles.signatureBox}>
          <p>Mengetahui:</p>
          <p>Pimpinan di Instansi tempat bekerja,</p>
          <div className="h-24"></div>
          <p>(..........................................)</p>
          <p className="text-[10pt]">(Nama lengkap dan jabatan)*</p>
        </div>
        <div className={styles.signatureBox}>
          <p>Yang membuat pernyataan,</p>
          <div className="h-24 flex items-center justify-center italic text-gray-400">Materai 10.000</div>
          <p className="font-bold underline uppercase">{data.applicant.fullName}</p>
          <p className="text-[10pt]">(Nama lengkap)</p>
        </div>
      </div>
    </PageWrapper>
  );
};

// 3. LAMPIRAN III - PERMOHONAN SBUM
export const LampiranIII_Internal: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className="absolute top-[20mm] right-[20mm] italic border border-black px-4 py-1">Format Internal</div>
    <div className="text-[10pt] mb-6">
      <strong>Lampiran III</strong><br />
      Memo SMD No. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /M/SMD/PPD/XII/2025 tanggal &nbsp;&nbsp;&nbsp;&nbsp; Desember 2025
    </div>
    
    <div className={styles.docTitle}>SURAT PERNYATAAN PERSETUJUAN</div>
    <div className={styles.docSubTitle}>PENYALURAN KPR SEJAHTERA FLPP TA 2025</div>

    <p className="mb-2">Yang bertanda tangan di bawah ini:</p>
    <table className="mb-2">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
        <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
      </tbody>
    </table>
    <p className="mb-4 italic">Selaku pemohon.</p>

    {data.maritalStatus === MaritalStatus.MARRIED && data.spouse && (
      <>
        <table className="mb-2">
          <tbody>
            <tr><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.spouse.fullName}</td></tr>
            <tr><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>{data.spouse.ktpNumber || '....................'}</td></tr>
            <tr><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.spouse.pob}, {formatLongDate(data.spouse.dob)}</td></tr>
            <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.spouse.job}</td></tr>
            <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.spouse.address}</td></tr>
          </tbody>
        </table>
        <p className="mb-4 italic">Selaku istri/suami* pemohon.</p>
      </>
    )}

    <p className="text-justify mb-4">
      Menyatakan dengan sesungguhnya bahwa sehubungan dengan kerja sama penyaluran Subsidi Bantuan Uang Muka Perumahan 
      (SBUM) Tahun 2025 masih dalam proses kajian internal Kementerian PKP, maka atas fasilitas Kredit Pemilikan Rumah (KPR) 
      Sejahtera FLPP yang Saya dan istri/suami* ajukan maka Saya dan istri/suami*:
    </p>

    <div className="space-y-4 text-justify mb-8">
      <div className="flex gap-4">
        <span>1.</span>
        <p>Mengetahui dan menyetujui bahwa penyaluran KPR Sejahtera FLPP TA 2025 dimaksud atas pembelian rumah umum tapak pada proyek perumahan <strong>{data.property.projectName}</strong> Cluster <strong>....................</strong> Blok/No <strong>{data.property.kavlingNumber || '........'}</strong> yang dikembangkan oleh <strong>{COMPANY_INFO.name}</strong> dengan fasilitas SBUM yang akan dibayarkan apabila telah dapat ditagihkan dan sesuai dengan ketentuan pada PKS SBUM TA 2026.</p>
      </div>
      <div className="flex gap-4">
        <span>2.</span>
        <p>Bersedia dilakukan pemblokiran dana sebesar Rp. 4.000.000,-/Rp. 10.000.000,- *) dan bersedia untuk dilakukan pemindahbukuan atas dana tersebut ke Rekening Developer dengan Nomor Rekening: <strong>{COMPANY_INFO.btnAccount}</strong> atas nama <strong>{COMPANY_INFO.name}</strong> sebagai pengganti Dana SBUM apabila fasilitas SBUM tidak dapat ditagihkan kepada Satker PUPR.</p>
      </div>
    </div>

    <p className="text-justify mb-4">Demikian surat pernyataan ini saya buat dengan sebenarnya tanpa paksaan dari pihak manapun dan apabila di kemudian hari pernyataan saya ini tidak benar, saya bersedia mengembalikan seluruh subsidi yang saya terima.</p>
    <p className="mb-8">Demikian surat pernyataan ini saya buat dengan sebenar-benarnya tanpa paksaan dari pihak manapun.</p>

    <div className="flex justify-between">
      <div className="text-center min-w-[200px]">
        <p>Menyetujui,</p>
        <div className="h-24"></div>
        <p>( ............................. )</p>
        <p className="text-[10pt]">Nama Lengkap Suami/Istri*</p>
      </div>
      <div className="text-center min-w-[200px]">
        <p>................., .......................... 20...</p>
        <p className="text-[9pt] leading-none mb-4">Kota/Kabupaten, tanggal bulan tahun</p>
        <div className="h-10 flex items-center justify-center italic text-gray-400">
           <div className="border border-dotted border-black p-2 text-[8pt]">Meterai Rp. 10.000,-</div>
        </div>
        <div className="h-10"></div>
        <p>( ............................. )</p>
        <p className="text-[10pt]">Nama Lengkap Pemohon</p>
      </div>
    </div>

    <div className="mt-8 text-center">
      <p>Mengetahui,</p>
      <p>Pengembang <strong>{COMPANY_INFO.name}</strong></p>
      <div className="h-24"></div>
      <p>( ............................. )</p>
      <p className="text-[10pt]">Nama Lengkap, Jabatan dan Stempel</p>
    </div>
    <p className="mt-8 text-[9pt] italic">*) coret salah yang tidak perlu</p>
  </PageWrapper>
);

// 4. Surat Pengakuan Kekurangan Bayar Uang Muka
export const ShortfallPaymentStatement: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle}>SURAT PENGAKUAN KEKURANGAN BAYAR UANG MUKA</div>
    <p className="mt-8 mb-4">Saya yang bertanda tangan di bawah ini:</p>
    <table className="mb-6">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
        <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-2 leading-relaxed">
      Dengan ini menyatakan bahwa saya telah melakukan pembayaran uang muka sebesar<br/>
      Rp. {data.property.paidDP.toLocaleString('id-ID')},- ({numberToWords(data.property.paidDP)}) dan masih memiliki kekurangan bayar uang muka sebesar<br/>
      Rp. ..................(.............................) untuk pembelian Rumah Umum Tapak kepada:
    </p>
    <table className="mb-4">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama Pengembang</td><td className={styles.tableColon}>:</td><td><strong>{COMPANY_INFO.name}</strong></td></tr>
        <tr><td className={styles.tableLabel}>Alamat Rumah yang Dibeli</td><td className={styles.tableColon}>:</td><td>{data.property.houseAddress}</td></tr>
        <tr><td className={styles.tableLabel}>Harga Jual Rumah</td><td className={styles.tableColon}>:</td><td>{formatCurrency(data.property.price)}</td></tr>
        <tr><td className={styles.tableLabel}>Besaran Uang Muka</td><td className={styles.tableColon}>:</td><td>{formatCurrency(data.property.downPayment)}</td></tr>
        <tr><td className={styles.tableLabel}>Bank Pelaksana</td><td className={styles.tableColon}>:</td><td>Bank BTN Kantor Cabang {COMPANY_INFO.city}</td></tr>
      </tbody>
    </table>
    <p className="mb-8">Demikian kami sampaikan, atas perhatiannya kami ucapkan terima kasih.</p>
    <div className={styles.signatureArea}>
      <div className={styles.signatureBox}>
        <p>Menyetujui,</p>
        <p><strong>{COMPANY_INFO.name.toUpperCase()}</strong></p>
        <div className="h-24"></div>
        <p>( {COMPANY_INFO.director} )</p>
        <p className="text-[10pt]">Nama Pengembang</p>
      </div>
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p><strong>PEMOHON</strong></p>
        <div className="h-24 flex items-center justify-center italic text-gray-400">Materai Rp10.000,-</div>
        <p>( {data.applicant.fullName} )</p>
        <p className="text-[10pt]">Nama Lengkap</p>
      </div>
    </div>
  </PageWrapper>
);

// 5. Standing Instruction (Debitur & Developer)
export const StandingInstructionDebitur: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle}>SURAT PERINTAH PEMINDAHBUKUAN DANA SBUM</div>
    <div className={styles.docSubTitle}>(STANDING INSTRUCTION)</div>
    <p className="text-justify mb-4">
      Sehubungan dengan permohonan dana Subsidi Bantuan Uang Muka (SBUM) kepada Kepala Satuan Kerja 
      Direktorat Jenderal Pembiayaan Perumahan Kementerian Pekerjaan Umum dan Perumahan Rakyat, maka saya 
      yang bertanda tangan di bawah ini :
    </p>
    <table className="mb-6">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
        <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-4 leading-relaxed">
      Dengan ini memberikan kuasa kepada PT. Bank Tabungan Negara (Persero) Tbk. Kantor 
      Cabang {COMPANY_INFO.city} untuk melakukan pemindahbukuan pencairan dana Subsidi Bantuan Uang Muka 
      (SBUM) senilai Rp. 4.000.000,- (Empat Juta Rupiah) untuk digunakan sebagai pengurang 
      pokok kredit/pembayaran kekurangan uang muka pembelian Rumah Umum Tapak*), kepada :
    </p>
    <table className="mb-4">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama Pengembang</td><td className={styles.tableColon}>:</td><td><strong>{COMPANY_INFO.name}</strong></td></tr>
        <tr><td className={styles.tableLabel}>Nomor Rekening</td><td className={styles.tableColon}>:</td><td>{COMPANY_INFO.btnAccount}</td></tr>
        <tr><td className={styles.tableLabel}>Rekening Atas Nama</td><td className={styles.tableColon}>:</td><td><strong>{COMPANY_INFO.name}</strong></td></tr>
        <tr><td className={styles.tableLabel}>Pada Bank</td><td className={styles.tableColon}>:</td><td>Bank BTN Kantor Cabang {COMPANY_INFO.city}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-8 italic">
      Demikian Standing Instruction ini dibuat tanpa adanya paksaan dari pihak manapun. Akibat apapun yang mungkin 
      timbul dari pelaksanaan penyaluran dana oleh PT. Bank Tabungan Negara (Persero) Tbk. berdasarkan Standing 
      Instruction ini adalah sepenuhnya menjadi tanggung jawab saya pribadi.
    </p>
    <div className={styles.signatureArea}>
      <div className={styles.signatureBox}>
        <p>Menyetujui,</p>
        <p>PT. BANK TABUNGAN NEGARA (PERSERO) Tbk.</p>
        <p>KANTOR CABANG {COMPANY_INFO.city.toUpperCase()}</p>
        <div className="h-24"></div>
        <p>(..........................................)</p>
        <p className="text-[10pt]">Nama Lengkap, Jabatan, Stempel</p>
      </div>
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p><strong>PEMBUAT STANDING INSTRUCTION</strong></p>
        <div className="h-24 flex items-center justify-center italic text-gray-400">Materai</div>
        <p>( {data.applicant.fullName} )</p>
        <p className="text-[10pt]">Nama Lengkap Pembuat SI</p>
      </div>
    </div>
  </PageWrapper>
);

export const StandingInstructionDeveloper: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle}>SURAT PERINTAH PEMINDAHBUKUAN DANA SBUM</div>
    <div className={styles.docSubTitle}>(STANDING INSTRUCTION)</div>
    <p className="text-justify mb-4">
      Sehubungan dengan pencairan Subsidi Bantuan Uang Muka (SBUM) kepada Debitur KPR Bersubsidi, maka saya 
      yang bertanda tangan di bawah ini :
    </p>
    <table className="mb-6">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama Pengembang</td><td className={styles.tableColon}>:</td><td><strong>{COMPANY_INFO.name}</strong></td></tr>
        <tr><td className={styles.tableLabel}>Nomor Rekening</td><td className={styles.tableColon}>:</td><td>{COMPANY_INFO.btnAccount}</td></tr>
        <tr><td className={styles.tableLabel}>Rekening Atas Nama</td><td className={styles.tableColon}>:</td><td><strong>{COMPANY_INFO.name}</strong></td></tr>
        <tr><td className={styles.tableLabel}>Pada Bank</td><td className={styles.tableColon}>:</td><td>Bank BTN Kantor Cabang {COMPANY_INFO.city}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-4 leading-relaxed">
      Dengan ini memberikan kuasa kepada PT. Bank Tabungan Negara (Persero) Tbk. Kantor 
      Cabang {COMPANY_INFO.city} untuk melakukan pemindahbukuan pencairan dana Subsidi Bantuan Uang Muka 
      (SBUM) senilai Rp. 4.000.000,- (Empat Juta Rupiah) untuk digunakan sebagai pengganti 
      tambahan uang muka pembelian Rumah Umum Tapak*), kepada :
    </p>
    <table className="mb-4">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Nomor Rekening</td><td className={styles.tableColon}>:</td><td>{data.applicant.btnAccountNumber || '....................'}</td></tr>
        <tr><td className={styles.tableLabel}>Rekening Atas Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>Pada Bank</td><td className={styles.tableColon}>:</td><td>Bank BTN Kantor Cabang {COMPANY_INFO.city}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-8 italic">
      Demikian Standing Instruction ini dibuat tanpa adanya paksaan dari pihak manapun. Akibat apapun yang mungkin 
      timbul dari pelaksanaan penyaluran dana oleh PT. Bank Tabungan Negara (Persero) Tbk. berdasarkan Standing 
      Instruction ini adalah sepenuhnya menjadi tanggung jawab saya pribadi.
    </p>
    <div className={styles.signatureArea}>
      <div className={styles.signatureBox}>
        <p>Menyetujui,</p>
        <p>PT. BANK TABUNGAN NEGARA (PERSERO) Tbk.</p>
        <p>KANTOR CABANG {COMPANY_INFO.city.toUpperCase()}</p>
        <div className="h-24"></div>
        <p>(..........................................)</p>
        <p className="text-[10pt]">Nama Lengkap, Jabatan, Stempel</p>
      </div>
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p><strong>PEMBUAT STANDING INSTRUCTION</strong></p>
        <div className="h-24 flex items-center justify-center italic text-gray-400">Materai</div>
        <p>( {COMPANY_INFO.director} )</p>
        <p className="text-[10pt]">Nama Lengkap dan Stempel Pembuat SI</p>
      </div>
    </div>
  </PageWrapper>
);

// 6. LAMPIRAN XI - INTERNAL (2 HALAMAN)
export const LampiranXI_Internal: React.FC<{ data: AppState }> = ({ data }) => (
  <>
    <PageWrapper>
      <div className="absolute top-[20mm] right-[20mm] italic border border-black px-4 py-1">Format Internal</div>
      <div className="text-[10pt] mb-6">
        <strong>Lampiran XI</strong><br />
        Memo SMD No. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /M/SMD/PPD/XII/2025 tanggal &nbsp;&nbsp;&nbsp;&nbsp; Desember 2025
      </div>
      <div className={styles.docTitle}>SURAT PERNYATAAN PEMOHON KPR BERSUBSIDI BTN</div>
      <p className="text-justify mt-4 mb-4">
        Berkenaan dengan persetujuan Kredit Pemilikan Rumah Bersubsidi BTN (KPR Bersubsidi BTN) yang disampaikan PT Bank Tabungan 
        Negara (Persero) Tbk (Bank BTN) melalui Surat Persetujuan Pemberian Kredit (SP3K) No………………. tanggal………………………., kami 
        yang bertanda tangan dibawah ini:
      </p>
      <table className="mb-2 w-full">
        <tbody>
          <tr><td className="w-6">•</td><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
          <tr><td>•</td><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
          <tr><td>•</td><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
          <tr><td>•</td><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
          <tr><td>•</td><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
        </tbody>
      </table>
      <p className="mb-4 italic ml-6">Selaku Calon Debitur.</p>
      {data.maritalStatus === MaritalStatus.MARRIED && data.spouse && (
        <>
          <table className="mb-2 w-full">
            <tbody>
              <tr><td className="w-6">•</td><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.spouse.fullName}</td></tr>
              <tr><td>•</td><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>{data.spouse.ktpNumber || '....................'}</td></tr>
              <tr><td>•</td><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.spouse.pob}, {formatLongDate(data.spouse.dob)}</td></tr>
              <tr><td>•</td><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.spouse.job}</td></tr>
              <tr><td>•</td><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.spouse.address}</td></tr>
            </tbody>
          </table>
          <p className="mb-4 italic ml-6">Selaku suami/istri* Calon Debitur.</p>
        </>
      )}
      <p className="mb-2">Menyatakan dengan sesungguhnya bahwa:</p>
      <div className="space-y-1 text-justify text-[10.5pt] leading-tight">
        <div className="flex gap-4"><span>1.</span><p>Telah melaksanakan setiap proses permohonan KPR Bersubsidi BTN sesuai dengan ketentuan Bank BTN dan menyetujui SP3K dimaksud berdasarkan itikad baik, dalam keadaan bebas, mandiri dan tidak di bawah tekanan maupun pengaruh dari pihak lain (independency).</p></div>
        <div className="flex gap-4"><span>2.</span><p>Telah menerima dan memahami dengan baik setiap penjelasan yang disampaikan Bank BTN mengenai fasilitas KPR Bersubsidi BTN, hak dan kewajiban kami sebagai Debitur serta kewajiban lainnya sesuai ketentuan peraturan perundang – undangan.</p></div>
        <div className="flex gap-4"><span>3.</span><p>Bersedia melakukan aktivasi ulang QR Code setiap tahun hingga tahun ke 5 (lima) sejak akad KPR Bersubsidi BTN sesuai dengan ketentuan Pemerintah.</p></div>
        <div className="flex gap-4"><span>4.</span><p>Bersedia menyerahkan data pribadi (KTP dan NPWP) untuk mendapatkan fasilitas KPR Sejahtera dan semua data lainnya yang diperlukan oleh Regulator melalui Bank.</p></div>
        <div className="flex gap-4"><span>5.</span><p>Bersedia menyerahkan dokumen bukti pelaporan Pajak :<br/>a. Telah menjadi wajib pajak >1 (satu) tahun dan penghasilan > PTKP, melampirkan SPT PPh.<br/>b. Belum menjadi wajib pajak &lt;1 (satu) tahun, melampirkan surat pernyataan penyerahan SPT PPh tahun selanjutnya.<br/>c. Apabila dikemudian hari diperlukan penyampaian SPT PPH, saya bersedia menyerahkan SPT PPH kepada Pihak Bank.</p></div>
        <div className="flex gap-4"><span>6.</span><p>Seluruh dokumen persyaratan yang disampaikan kepada Bank BTN untuk memperoleh fasilitas subsidi adalah benar dan dapat dipertanggungjawabkan keabsahannya baik secara formil maupun material.</p></div>
        <div className="flex gap-4"><span>7.</span><p>Bersedia untuk menanggung segala biaya yang meliputi biaya asuransi, biaya pengikatan agunan, dan biaya lainnya yang timbul karena terjadinya penghentian KPR Bersubsidi BTN dan/atau perubahan/konversi menjadi KPR Non-Subsidi.</p></div>
        <div className="flex gap-4"><span>8.</span><p>Tidak akan menjanjikan atau memberikan sesuatu baik secara langsung dan tidak langsung, baik atas inisiatif sendiri maupun orang lain, baik dengan menggunakan sarana elektronik atau tanpa sarana elektronik, baik dalam bentuk uang atau bukan uang seperti hadiah, cinderamata, komisi, pinjaman tanpa bunga, tiket perjalanan, fasilitas penginapan, perjalanan wisata, pengobatan cuma – cuma, hiburan dan fasilitas lainnya atau bentuk lainnya kepada setiap pejabat and/atau pegawai Bank BTN termasuk anggota keluarga intinya.</p></div>
        <div className="flex gap-4"><span>9.</span><p>Apabila dikemudian hari diketahui bahwa pernyataan kami ini dan pernyataan lainnya yang kami sampaikan kepada Bank BTN tidak benar dan/atau saya penuhi, maka saya bersedia mengembalikan seluruh subsidi yang telah saya terima dari Pemerintah, bersedia dikenakan sanksi sesuai dengan ketentuan peraturan perundang – undangan dan bersedia mengubah/mengkonversi menjadi KPR Non Subsidi.</p></div>
      </div>
    </PageWrapper>
    <PageWrapper>
      <p className="mt-4">Demikian surat pernyataan ini saya buat dengan sebenar-benarnya tanpa paksaan dari pihak manapun.</p>
      <div className="flex justify-between mt-12">
        <div className="text-center min-w-[200px]">
          <p>Menyetujui,</p>
          <div className="h-24"></div>
          <p>( ............................. )</p>
          <p className="text-[10pt]">Nama Lengkap Suami/Istri*</p>
        </div>
        <div className="text-center min-w-[200px]">
          <p>................., .......................... 20...</p>
          <p className="text-[9pt] leading-none mb-4">Kota/Kabupaten, tanggal bulan tahun</p>
          <div className="h-10 flex items-center justify-center italic text-gray-400">
             <div className="border border-dotted border-black p-2 text-[8pt]">Meterai secukupnya</div>
          </div>
          <div className="h-10"></div>
          <p>( ............................. )</p>
          <p className="text-[10pt]">Nama Lengkap Pemohon</p>
        </div>
      </div>
      <div className="mt-12 text-center">
        <p>Mengetahui,</p>
        <p>Pimpinan Tempat Bekerja/Kepala Desa/Lurah* .............................</p>
        <div className="h-24"></div>
        <p>( ............................. )</p>
        <p className="text-[10pt]">Nama Lengkap, Jabatan dan Stempel</p>
      </div>
      <p className="mt-8 text-[9pt] italic">*) coret salah yang tidak perlu</p>
    </PageWrapper>
  </>
);

// 7. LAMPIRAN VI - EKSTERNAL (2 HALAMAN)
export const LampiranVI_External: React.FC<{ data: AppState }> = ({ data }) => (
  <>
    <PageWrapper>
      <div className="absolute top-[20mm] right-[20mm] italic border border-black px-4 py-1">Format Eksternal</div>
      <div className="text-[10pt] mb-6">
        <strong>Lampiran VI</strong><br />
        Memo SMD No. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /M/SMD/PPD/XII/2025 tanggal &nbsp;&nbsp;&nbsp;&nbsp; Desember 2025
      </div>
      <div className={styles.docTitle}>SURAT PERNYATAAN PEMOHON KPR BERSUBSIDI BTN</div>
      <p className="mt-4 mb-2">Yang bertanda tangan di bawah ini:</p>
      <table className="mb-2">
        <tbody>
          <tr><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
          <tr><td className={styles.tableLabel}>Tempat/Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
          <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
          <tr><td className={styles.tableLabel}>No. KTP/NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
          <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
        </tbody>
      </table>
      <p className="mb-4 italic">Selaku Pemohon.</p>
      {data.maritalStatus === MaritalStatus.MARRIED && data.spouse && (
        <>
          <table className="mb-2">
            <tbody>
              <tr><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.spouse.fullName}</td></tr>
              <tr><td className={styles.tableLabel}>Tempat/Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.spouse.pob}, {formatLongDate(data.spouse.dob)}</td></tr>
              <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.spouse.job}</td></tr>
              <tr><td className={styles.tableLabel}>No. KTP/NIK</td><td className={styles.tableColon}>:</td><td>{data.spouse.ktpNumber || '....................'}</td></tr>
              <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.spouse.address}</td></tr>
            </tbody>
          </table>
          <p className="mb-4 italic">Selaku suami/istri* pemohon.</p>
        </>
      )}
      <p className="mb-4">Menyatakan dengan sesungguhnya bahwa:</p>
      <div className="space-y-2 text-justify text-[10.5pt]">
        <div className="flex gap-4"><span>1.</span><p>Saya memiliki gaji/upah pokok/penghasilan bersih/upah rata – rata *) per bulan sebesar Rp. ....................................,- (........................................................)</p></div>
        <div className="flex gap-4"><span>2.</span><p>Saya dan (istri/suami*)) tidak memiliki hak kepemilikan atas rumah pada saat pengajuan pembiayaan KPR Bersubsidi.</p></div>
        <div className="flex gap-4"><span>3.</span><p>Saya dan (istri/suami*)) belum pernah menerima subsidi atau bantuan pembiayaan perumahan dari pemerintah terkait kredit/pembiayaan perumahan dari pemerintah terkait kredit/pembiayaan kepemilikan rumah dan pembangunan Rumah Swadaya.</p></div>
        <div className="flex gap-4"><span>4.</span><p>Saya membeli Rumah Umum Tapak/Sarusun Umum dengan harga Rp............................................,- (........................................................) dari <strong>{COMPANY_INFO.name}</strong></p></div>
        <div className="flex gap-4"><span>5.</span><p>Saya dan (istri/suami*)) akan menggunakan Rumah Umum Tapak/Sarusun Umum sebagai tempat tinggal saya dan/atau keluarga dalam kurun waktu paling lambat 1 (satu) tahun setelah serah terima rumah.</p></div>
        <div className="flex gap-4"><span>6.</span><p>Saya dan (istri/suami*)) tidak akan menyewakan/mengontrakkan, memperjualbelikan atau memindahtangankan dengan bentuk perbuatan hukum apapun, kecuali:<br/>a. penghunian telah melampaui 5 (lima) tahun untuk Rumah Umum Tapak;<br/>b. penghunian telah melampaui 20 (dua puluh) tahun untuk Sarusun Umum;<br/>c. pindah tempat tinggal sesuai ketentuan peraturan perundang-undangan; atau<br/>d. meninggal dunia (pewarisan); atau<br/>e. untuk kepentingan Bank BTN dalam rangka penyelesaian kredit bermasalah.</p></div>
        <div className="flex gap-4"><span>7.</span><p>Bahwa semua dokumen persyaratan yang disampaikan kepada Bank BTN untuk memperoleh subsidi adalah benar dan dapat dipertanggungjawabkan keabsahannya.</p></div>
        <div className="flex gap-4"><span>8.</span><p>Apabila di kemudian hari pernyataan saya ini tidak benar dan/atau tidak saya penuhi, saya bersedia mengembalikan seluruh dana kemudahan dan/atau bantuan pembiayaan perumahan yang telah diperoleh melalui Bank BTN dan bersedia dikenakan sanksi sesuai dengan ketentuan peraturan perundang- undangan.</p></div>
      </div>
    </PageWrapper>
    <PageWrapper>
      <p className="mt-4">Demikian surat pernyataan ini saya buat dengan sebenar-benarnya tanpa paksaan dari pihak manapun.</p>
      <div className="flex justify-between mt-12">
        <div className="text-center min-w-[200px]">
          <p>Menyetujui,</p>
          <div className="h-24"></div>
          <p>( ............................. )</p>
          <p className="text-[10pt]">Nama Lengkap Suami/Istri*</p>
        </div>
        <div className="text-center min-w-[200px]">
          <p>................., .......................... 20...</p>
          <p className="text-[9pt] leading-none mb-4">Kota/Kabupaten, tanggal bulan tahun</p>
          <p>Yang membuat pernyataan,</p>
          <div className="h-10 flex items-center justify-center italic text-gray-400">
             <div className="border border-dotted border-black p-2 text-[8pt]">Meterai Rp. 10.000,-</div>
          </div>
          <div className="h-10"></div>
          <p>( ............................. )</p>
          <p className="text-[10pt]">Nama Lengkap Pemohon</p>
        </div>
      </div>
      <div className="mt-12 text-center">
        <p>Mengetahui,</p>
        <p>Pimpinan Tempat Bekerja/Kepala Desa/Lurah* .............................</p>
        <div className="h-24"></div>
        <p>( ............................. )</p>
        <p className="text-[10pt]">Nama Lengkap, Jabatan dan Stempel</p>
      </div>
      <p className="mt-8 text-[9pt] italic">*) coret salah yang tidak perlu</p>
    </PageWrapper>
  </>
);

// 8. Surat Pernyataan Penghunian
export const HabitationStatement: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper narrow>
    <div className="text-[10.5pt] leading-tight">
      <div className={styles.docTitle}>SURAT PERNYATAAN PENGHUNIAN RUMAH UMUM BERSUBSIDI</div>
      <p className="mt-4 mb-2">Yang bertanda tangan di bawah ini:</p>
      <table className="mb-4 text-[10.5pt]">
        <tbody>
          <tr><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
          <tr><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
          <tr><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
          <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
          <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
        </tbody>
      </table>
      <p className="mb-2">Selaku Debitur KPR Bersubsidi BTN menyatakan dengan sesungguhnya bahwa:</p>
      <div className="space-y-1 text-justify mb-4">
        <p>1. Saya telah memahami ketentuan penghunian rumah sejahtera sebagaimana dimaksud di dalam Peraturan Menteri Pekerjaan Umum dan Perumahan Rakyat.</p>
        <p>2. Saya menyatakan bahwa:</p>
        <div className="pl-6">
          <p>- berpenghasilan tidak melebihi ketentuan batas penghasilan kelompok sasaran KPR Bersubsidi;</p>
          <p>- saya dan istri/suami*) tidak memiliki rumah;</p>
          <p>- saya dan istri/suami*) tidak pernah menerima subsidi kepemilikan rumah.</p>
          <p>- menggunakan sendiri dan menghuni rumah umum tapak atau sarusun umum sebagai tempat tinggal dalam jangka waktu paling lambat 1 (satu) tahun setelah serah terima rumah.</p>
          <p>- tidak akan menyewakan dan/atau mengalihkan kepemilikan rumah umum tapak atau sarusun umum dengan bentuk perbuatan hukum apapun, kecuali sesuai ketentuan Peraturan Menteri Pekerjaan Umum dan Perumahan Rakyat.</p>
        </div>
        <p>3. Bahwa semua dokumen persyaratan yang disampaikan kepada Bank BTN untuk memperoleh KPR Bersubsidi BTN adalah benar dan dapat dipertanggungjawabkan keabsahannya.</p>
        <p>4. Apabila di kemudian hari pernyataan saya ini tidak benar dan/atau tidak saya penuhi, saya bersedia dan memberikan kuasa kepada Bank BTN untuk menghentikan fasilitas KPR Bersubsidi BTN dan/atau mengubah menjadi KPR BTN Non-Subsidi, setelah Bank BTN menerima surat permintaan penghentian KPR Bersubsidi dari pihak yang berwenang.</p>
        <p>5. Saya bersedia untuk menanggung segala biaya yang meliputi biaya asuransi, biaya pengikatan agunan, dan biaya lainnya yang timbul atas penghentian KPR Bersubsidi BTN.</p>
      </div>

      <p className="mb-4">Demikian surat pernyataan ini dibuat dengan sebenar benarnya tanpa paksaan dari pihak manapun.</p>

      <div className={styles.signatureArea + " mt-8"}>
        <div className={styles.signatureBox}>
          <p>Menyetujui,</p>
          <div className="h-16"></div>
          <p>(..........................................)</p>
          <p className="text-[9pt]">Nama Lengkap Suami/Istri*</p>
        </div>
        <div className={styles.signatureBox}>
          <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
          <div className="h-16 flex items-center justify-center italic text-gray-400">
            <div className="border border-dotted border-black p-1 text-[8pt]">Materai Rp10.000,-</div>
          </div>
          <p>( {data.applicant.fullName} )</p>
          <p className="text-[9pt]">Nama Lengkap Debitur</p>
        </div>
      </div>

      <div className="mt-8 flex justify-center w-full">
        <div className="text-center w-full">
          <p>Mengetahui,</p>
          <p><strong>PT. BANK TABUNGAN NEGARA (PERSERO) Tbk.</strong></p>
          <p><strong>KANTOR CABANG PANGKALPINANG</strong></p>
          <div className="h-24"></div>
          <p>(..........................................................)</p>
        </div>
      </div>
    </div>
  </PageWrapper>
);

// 9. Surat Kuasa Pendebetan Dana
export const DebetKuasa: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className="text-[10pt] mb-6">
      <strong>Lampiran XI</strong><br />
      Memo SMD No. 3254 /M/SMD/PPD/XII/2022 tanggal 30 Desember 2022<br />
      Perihal Ketentuan Realisasi KPR Sejahtera FLPP Tahun 2023
    </div>
    <div className={styles.docTitle}>SURAT KUASA PENDEBETAN DANA</div>
    <p className="mt-6 mb-2">Yang bertanda tangan di bawah ini:</p>
    <table className="mb-4">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Tempat, Tanggal Lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
        <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
      </tbody>
    </table>
    <p className="mb-4">yang dalam hal ini bertindak untuk dan atas nama sendiri. Selanjutnya disebut “Pemberi Kuasa”.</p>
    <p className="text-justify mb-4 leading-relaxed">
      PT. Bank Tabungan Negara (Persero) Tbk., berkedudukan di Jalan Gajah Mada No. 01 Jakarta Pusat yang 
      dalam hal ini diwakili oleh ..................................., selaku ........................... di PT. Bank Tabungan Negara (Persero) Tbk. Kantor Cabang ................................................. Selanjutnya disebut “Penerima Kuasa”.
    </p>
    <p className="text-justify mb-4 leading-relaxed">
      dengan ini Pemberi Kuasa memberi kuasa kepada Penerima Kuasa untuk melakukan pendebetan dana 
      pada Nomor Rekening Tabungan Pemberi Kuasa dengan nomor : .................................................... atas 
      nama ............................................. atas biaya asuransi, biaya pengikatan agunan, dan biaya lainnya yang 
      timbul atas penghentian KPR Bersubsidi BTN yang disebabkan oleh dokumen pernyataan yang tidak benar 
      dan/atau tidak dipenuhi dalam proses pengajuan dan pelaksanaan KPR Bersubsidi BTN.
    </p>
    <p className="text-justify mb-8 leading-relaxed">
      Kuasa ini diberikan dengan Hak Substitusi, tidak dapat dicabut kembali and tidak akan berakhir karena 
      sebab-sebab yang tercantum dalam pasal 1813 Kitab Undang-Undang Hukum Perdata atau karena sebab 
      apapun juga.
    </p>
    <div className={styles.signatureArea}>
      <div className={styles.signatureBox}>
        <p><strong>PENERIMA KUASA</strong></p>
        <p><strong>PT. BANK TABUNGAN NEGARA (PERSERO) Tbk.</strong></p>
        <p><strong>KANTOR CABANG PANGKALPINANG</strong></p>
        <div className="h-24"></div>
        <p>(..........................................)</p>
        <p className="text-[10pt]">Nama Lengkap, Jabatan</p>
      </div>
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p>PEMBERI KUASA</p>
        <div className="h-24 flex items-center justify-center italic text-gray-400">Materai Rp10.000,-</div>
        <p>( {data.applicant.fullName} )</p>
        <p className="text-[10pt]">Nama Lengkap Debitur</p>
      </div>
    </div>
  </PageWrapper>
);

// 10. Berita Acara Serah Terima
export const LampiranVIII_External: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className="absolute top-[20mm] right-[20mm] italic border border-black px-4 py-1">Format Eksternal</div>
    <div className="text-[10pt] mb-6">
      <strong>Lampiran VIII</strong><br />
      Memo SMD No. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; /M/SMD/PPD/XII/2025 tanggal &nbsp;&nbsp;&nbsp;&nbsp; Desember 2025
    </div>
    
    <div className={styles.docTitle}>BERITA ACARA SERAH TERIMA</div>
    <div className={styles.docSubTitle}>RUMAH UMUM TAPAK</div>

    <p className="text-justify mb-4">
      Berdasarkan PPJB/AJB*) No. ........... Tanggal : ....... ..................... 20….. telah dilakukan serah terima pada tanggal ....... ..................... 20…..
      dari Pengembang <strong>{COMPANY_INFO.name}</strong> (diisi nama Pengembang) , selanjutnya disebut “Pihak Pertama”;
    </p>

    <p>Kepada pembeli:</p>
    <table className="mb-4">
      <tbody>
        <tr><td className="w-10">1.</td><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td>2.</td><td className={styles.tableLabel}>NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td>3.</td><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
        <tr><td>4.</td><td className={styles.tableLabel}>Nomor Telp./HP</td><td className={styles.tableColon}>:</td><td>{data.applicant.phone}</td></tr>
      </tbody>
    </table>
    <p className="mb-4">selanjutnya disebut “Pihak Kedua”</p>

    <p>Atas 1 (Satu) unit Rumah Umum Tapak pada lokasi sebagai berikut:</p>
    <table className="mb-4">
      <tbody>
        <tr><td className="w-10">1.</td><td className={styles.tableLabel}>Nama Perumahan</td><td className={styles.tableColon}>:</td><td>{data.property.projectName}</td></tr>
        <tr><td>2.</td><td className={styles.tableLabel}>No. Rumah</td><td className={styles.tableColon}>:</td><td>{data.property.kavlingNumber || '........'}</td></tr>
        <tr><td>3.</td><td className={styles.tableLabel}>Luas Tanah dan Lantai Rumah</td><td className={styles.tableColon}>:</td><td>{data.property.landSize} m2 / {data.property.houseSize} m2</td></tr>
        <tr><td>4.</td><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.property.houseAddress}</td></tr>
        <tr><td>5.</td><td className={styles.tableLabel}>Kota/Kabupaten/Provinsi</td><td className={styles.tableColon}>:</td><td>{COMPANY_INFO.city}, Bangka Belitung</td></tr>
      </tbody>
    </table>
    <p className="mb-4">Selanjutnya disebut “Obyek Serah Terima”</p>

    <p>Obyek Serah Terima dengan kondisi laik fungsi dan dilengkapi dengan:</p>
    <div className="space-y-1 ml-4 mb-4">
      <p>1. Jaringan air bersih sudah berfungsi;</p>
      <p>2. Jaringan listrik sudah berfungsi;</p>
      <p>3. Jalan lingkungan sudah selesai dan berfungsi;</p>
      <p>4. Saluran/drainase lingkungan sudah selesai dan berfungsi;</p>
      <p>5. Saluran air limbah/air kotor rumah tangga sudah selesai dan berfungsi; dan</p>
      <p>6. Sarana pewadahan sampah individual dan tempat pembuangan sampah sementara.</p>
    </div>

    <p className="text-justify mb-8">Demikian berita acara serah terima ini ditandatangani oleh kedua belah pihak dan dapat dipertanggungjawabkan.</p>

    <div className="flex justify-between mt-12">
      <div className="text-center min-w-[250px]">
        <p>Pihak Pertama/Kuasa*,</p>
        <p>…….……(diisi nama Pengembang) …………</p>
        <div className="h-24"></div>
        <p>( ............................. )</p>
        <p className="text-[10pt]">Nama Lengkap, Jabatan dan Stempel</p>
      </div>
      <div className="text-center min-w-[200px]">
        <p>Pihak Kedua</p>
        <div className="h-24"></div>
        <div className="h-4"></div>
        <p>( ............................. )</p>
        <p className="text-[10pt]">Nama Lengkap</p>
      </div>
    </div>
    <p className="mt-8 text-[9pt] italic">*) coret salah yang tidak perlu</p>
  </PageWrapper>
);

// 11. Surat Pernyataan PSU
export const PSUStatement: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper narrow>
    <div className={styles.docTitle}>SURAT PERNYATAAN PENYELESAIAN</div>
    <div className={styles.docSubTitle}>PRASARANA, SARANA & UTILITAS PERUMAHAN</div>
    <p className="mt-4 mb-2">Yang bertandatangan di bawah ini:</p>
    <table className="mb-4 text-[11pt]">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{COMPANY_INFO.director}</td></tr>
        <tr><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>1971040409720004</td></tr>
        <tr><td className={styles.tableLabel}>Alamat Kantor/Telp</td><td className={styles.tableColon}>:</td><td>{COMPANY_INFO.name} (JL. FATMAWATI KAMPAK)</td></tr>
        <tr><td className={styles.tableLabel}>Jabatan</td><td className={styles.tableColon}>:</td><td>Direktur Utama yang mewakili <strong>{COMPANY_INFO.name}</strong></td></tr>
      </tbody>
    </table>
    <p className="mb-2 text-[11pt]">Selaku pengembang pada proyek perumahan {data.property.projectName}</p>
    <div className="space-y-1 text-justify mb-2 text-[10pt] leading-tight">
      <p><strong>Menyatakan hal-hal sebagai berikut:</strong></p>
      <p>1. Bahwa rumah sejahtera yang dijual oleh <strong>{COMPANY_INFO.name}</strong> dan diserah terimakan kepada debitur Bank BTN pada saat akad kredit adalah dalam kondisi siap huni dan telah memenuhi persyaratan teknis keselamatan, keamanan dan kehandalan bangunan sesuai dengan ketentuan Pemerintah yang berlaku.</p>
      <p>2. Bahwa pada saat surat pernyataan ini ditandatangani, <strong>{COMPANY_INFO.name}</strong> telah menyerahkan bukti pembayaran biaya penyambungan listrik dari PLN dan jalan lingkungan telah dilakukan perkerasan badan jalan dan berfungsi.</p>
      <p>3. Bahwa <strong>{COMPANY_INFO.name}</strong> bersedia menyelesaikan jalan lingkungan paling lambat 3 (tiga) bulan sejak perjanjian kredit/akad pembiayaan KPR Bersubsidi</p>
      <p>4. Bahwa <strong>{COMPANY_INFO.name}</strong> bersedia menyediakan dana jaminan kepada Bank BTN berupa dana yang ditahan (danaretensi) dengan rincian sebagai berikut:</p>
      <div className="pl-6">
        <p>4.1 Dana yang ditahan untuk setiap debitur/unit rumah, berjumlah paling sedikit 2 (dua) kali nilai jalan lingkungan yang belum terselesaikan.</p>
        <p>4.2 Nilai jalan lingkungan adalah berdasarkan penilaian (appraisal) Bank BTN.</p>
        <p>4.3 Dana yang ditahan diambil dari hasil setiap pencairan KPR Bersubsidi untuk setiap debitur/unit rumah yang jalan lingkungan yang belum terselesaikan.</p>
      </div>
      <p>5. Dalam hal <strong>{COMPANY_INFO.name}</strong> tidak dapat menyelesaikan kewajiban sebagaimana dimaksud butir 3 di atas, maka bersedia dan menyetujui dana jaminan sebagaimana dimaksud butir 4 di atas digunakan oleh Bank BTN untuk memastikan kewajiban penyelesaian jalan lingkungan dengan sesuai dengan ketentuan Pemerintah yang berlaku.</p>
    </div>
    
    <p className="text-justify text-[10pt] leading-tight mb-2">
      Surat pernyataan ini adalah bagian yang tidak terpisahkan dari Perjanjian Kerjasama (PKS) dengan Bank BTN Kantor 
      Cabang {COMPANY_INFO.city} tentang Penyediaan Dukungan KPR BTN Bersubsidi 
      Nomor ....................................................... tanggal .............................
    </p>

    <p className="text-justify text-[10pt] leading-tight mb-4">
      Demikian surat pernyataan ini dibuat dengan sebenarnya tanpa paksaan dari pihak manapun dan apabila di kemudian hari pernyataan ini tidak benar, maka bersedia menerima konsekuensi sesuai dengan ketentuan Pemerintah dan Perundang-undangan yang berlaku.
    </p>

    <div className="flex justify-between items-end">
      <div className="text-[8pt] italic w-1/2">
        *) namadanjabatanditulislengkapdandisertai cap basahperusahaan
      </div>
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p>Yang membuat pernyataan,</p>
        <div className="h-16 flex items-center justify-center">
           <div className="border border-black p-2 text-[9pt] leading-none">Materai 10000<br/>0</div>
        </div>
        <p className="font-bold underline uppercase">{COMPANY_INFO.director}</p>
        <p className="text-[10pt]">Direktur</p>
      </div>
    </div>
  </PageWrapper>
);

// 12. Surat Pernyataan Tidak Memiliki Rumah
export const NoHouseStatement: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle} style={{marginTop: '40mm'}}>SURAT PERNYATAAN TIDAK MEMILIKI RUMAH</div>
    <p className="mt-8 mb-4">Yang bertandatangan di bawah ini:</p>
    <table className="mb-8">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>Tempat/tgl lahir</td><td className={styles.tableColon}>:</td><td>{data.applicant.pob}, {formatLongDate(data.applicant.dob)}</td></tr>
        <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>{data.applicant.jobTitle}</td></tr>
        <tr><td className={styles.tableLabel}>No. KTP</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
      </tbody>
    </table>
    <p className="mb-8">menyatakan bahwa sampai dengan surat pernyataan ini dibuat tidak memiliki hak kepemilikan atas rumah.</p>
    <p className="text-justify mb-12">
      Demikian surat pernyataan ini saya buat dengan sebenarnya tanpa paksaan dari pihak manapun dan apabila di kemudian hari 
      pernyataan saya ini tidak benar, saya bersedia mengembalikan seluruh subsidi yang saya terima.
    </p>
    <div className={styles.signatureArea}>
      <div className={styles.signatureBox}>
        <p>Mengetahui:</p>
        <p>Kepala Desa/Lurah,</p>
        <div className="h-28"></div>
        <p>(..........................................)</p>
        <p className="text-[10pt]">(Nama lengkap dan jabatan)*</p>
      </div>
      <div className={styles.signatureBox}>
        <p>Yang membuat pernyataan,</p>
        <div className="h-28 flex items-center justify-center italic text-gray-400">Materai 10.000</div>
        <p className="font-bold underline uppercase">{data.applicant.fullName}</p>
        <p className="text-[10pt]">(Nama lengkap)</p>
      </div>
    </div>
  </PageWrapper>
);

// 13. Surat Pernyataan Tidak Bekerja (Pasangan)
export const NoJobStatement: React.FC<{ data: AppState }> = ({ data }) => {
  if (data.maritalStatus !== MaritalStatus.MARRIED || !data.spouse) return null;
  return (
    <PageWrapper>
      <div className={styles.docTitle}>SURAT PERNYATAAN TIDAK BEKERJA</div>
      <p className="mt-8 mb-4">Yang bertandatangan di bawah ini:</p>
      <table className="mb-6">
        <tbody>
          <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.spouse.fullName}</td></tr>
          <tr><td className={styles.tableLabel}>Tempat/tgl lahir</td><td className={styles.tableColon}>:</td><td>{data.spouse.pob}, {formatLongDate(data.spouse.dob)}</td></tr>
          <tr><td className={styles.tableLabel}>Pekerjaan</td><td className={styles.tableColon}>:</td><td>MENGURUS RUMAH TANGGA</td></tr>
          <tr><td className={styles.tableLabel}>No. KTP/Passport</td><td className={styles.tableColon}>:</td><td>{data.spouse.ktpNumber || '....................'}</td></tr>
          <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.spouse.address}</td></tr>
        </tbody>
      </table>
      <p className="text-justify mb-6">
        Menyatakan dengan sesungguhnya bahwa sampai saat surat pernyataan ini ditandatangani, saya menyatakan bahwa saya tidak 
        memiliki pekerjaan/ mengurus rumah tangga.
      </p>
      <p className="text-justify mb-8">
        Demikian surat pernyataan ini saya buat dengan sebenarnya tanpa paksaan dari pihak manapun dan apabila di kemudian hari 
        pernyataan saya ini tidak benar, saya bersedia mengembalikan seluruh subsidi yang saya terima.
      </p>
      <div className="text-right mb-12">{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</div>
      <div className={styles.signatureArea}>
        <div className={styles.signatureBox}>
          <p>Mengetahui:</p>
          <p>Kepala Desa/Lurah,</p>
          <div className="h-24"></div>
          <p>(..........................................)</p>
          <p className="text-[10pt]">Nama lengkap dan jabatan)*</p>
        </div>
        <div className={styles.signatureBox}>
          <p>Yang membuat pernyataan,</p>
          <div className="h-24 flex items-center justify-center italic text-gray-400">Materai 10.000</div>
          <p className="font-bold underline uppercase">{data.spouse.fullName}</p>
          <p className="text-[10pt]">(Nama lengkap)</p>
        </div>
      </div>
    </PageWrapper>
  );
};
