
import React, { useState, useEffect } from 'react';
import { 
  JobType, 
  MaritalStatus, 
  AppState, 
  ApplicantData, 
  SpouseData, 
  PropertyData,
  HistoryEntry
} from './types';
import { COMPANY_INFO, DEFAULT_PROPERTY } from './constants';
import { FormInput } from './components/FormInput';
import { 
  SPR_Official, 
  DebetKuasa, 
  IncomeStatementFixed, 
  NoHouseStatement,
  ShortfallPaymentStatement,
  StandingInstructionDebitur,
  StandingInstructionDeveloper,
  HabitationStatement,
  PSUStatement,
  LampiranIII_Internal,
  LampiranVI_External,
  LampiranVIII_External,
  LampiranXI_Internal,
  NoJobStatement
} from './components/documents/DataEntryDocs';
import {
  AJBValidityStatement,
  CertificatePowerOfAttorney,
  SellAndVacatePowerOfAttorney,
  LandSizeStatement
} from './components/documents/AJBDocs';
import { Printer, Home, User, Users, Briefcase, FileText, LayoutGrid, Save, RotateCcw, CheckCircle2, ChevronRight, History, FileDown, Trash2, X, Search, FileType, Loader2 } from 'lucide-react';

const HISTORY_KEY = 'marlindo_properti_history';

const INITIAL_STATE: AppState = {
  applicant: {
    fullName: '', ktpNumber: '', npwpNumber: '', btnAccountNumber: '',
    pob: '', dob: '', address: '', phone: '',
    jobType: JobType.EMPLOYEE, jobTitle: '', companyName: '', monthlyIncome: 0
  },
  maritalStatus: MaritalStatus.SINGLE,
  property: {
    ...DEFAULT_PROPERTY,
    kavlingNumber: '', nibNumber: '', certificateDate: '',
    paidDP: 1730000, remainingDP: 0
  },
  dateOfDocument: new Date().toISOString().split('T')[0],
  documentType: 'data-entry'
};

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(INITIAL_STATE);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [saveStatus, setSaveStatus] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [currentId, setCurrentId] = useState<string | null>(null);

  useEffect(() => {
    const savedHistory = localStorage.getItem(HISTORY_KEY);
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  const handleSave = () => {
    const id = currentId || Date.now().toString();
    const newEntry: HistoryEntry = {
      id,
      clientName: state.applicant.fullName || 'Nasabah Baru',
      unitInfo: `${state.property.projectName} - Kav ${state.property.kavlingNumber || '?'}`,
      savedAt: new Date().toLocaleString('id-ID'),
      data: state
    };

    let updatedHistory;
    if (currentId) {
      updatedHistory = history.map(h => h.id === id ? newEntry : h);
    } else {
      updatedHistory = [newEntry, ...history];
      setCurrentId(id);
    }

    setHistory(updatedHistory);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
    setSaveStatus(true);
    setTimeout(() => setSaveStatus(false), 2000);
  };

  const handleReset = () => {
    if (window.confirm("Hapus data inputan dan buat berkas baru?")) {
      setState(INITIAL_STATE);
      setCurrentId(null);
    }
  };

  const loadFromHistory = (entry: HistoryEntry) => {
    setState(entry.data);
    setCurrentId(entry.id);
    setShowHistory(false);
  };

  const deleteHistory = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("Hapus data ini dari riwayat?")) {
      const updated = history.filter(h => h.id !== id);
      setHistory(updated);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
      if (currentId === id) setCurrentId(null);
    }
  };

  const handleDownloadPdf = async () => {
    const element = document.querySelector('.print-area');
    if (!element) return;

    setIsGenerating(true);

    // Reset scroll ke atas untuk menghindari offset koordinat pada html2canvas
    window.scrollTo(0, 0);

    const category = state.documentType === 'data-entry' ? 'Data Entry' : 'AJB Bank';
    const clientName = state.applicant.fullName || 'Nasabah';
    const project = state.property.projectName || 'Anjayo 16';
    const filename = `${clientName} - ${project} - ${category}.pdf`;

    const html2pdfLib = (window as any).html2pdf;
    if (!html2pdfLib) {
      alert("Library PDF belum siap. Tunggu sebentar atau refresh halaman.");
      setIsGenerating(false);
      return;
    }

    const opt = {
      margin: 0,
      filename: filename,
      image: { type: 'jpeg', quality: 1.0 },
      html2canvas: { 
        scale: 2, 
        useCORS: true,
        letterRendering: true,
        backgroundColor: '#ffffff',
        scrollY: 0,
        scrollX: 0
      },
      jsPDF: { 
        unit: 'mm', 
        format: 'a4', 
        orientation: 'portrait',
        compress: true
      },
      pagebreak: { mode: ['css', 'legacy'] }
    };

    try {
      // Tunggu sebentar agar render DOM selesai
      await new Promise(resolve => setTimeout(resolve, 500));
      await html2pdfLib().from(element).set(opt).save();
    } catch (error) {
      console.error("PDF Generation failed:", error);
      alert("Gagal mendownload PDF. Silakan coba lagi.");
    } finally {
      setIsGenerating(false);
    }
  };

  const updateApplicant = (field: keyof ApplicantData, val: any) => 
    setState(s => ({...s, applicant: {...s.applicant, [field]: val}}));
  
  const updateProperty = (field: keyof PropertyData, val: any) => 
    setState(s => ({...s, property: {...s.property, [field]: val}}));

  const updateSpouse = (field: keyof SpouseData, val: any) => 
    setState(s => ({...s, spouse: {...(s.spouse || {fullName:'', pob:'', dob:'', job:'', address:'', isWorking:false, ktpNumber:''}), [field]: val}}));

  const setDocType = (type: 'data-entry' | 'ajb-bank') => 
    setState(s => ({...s, documentType: type}));

  return (
    <div className="min-h-screen bg-[#f1f5f9] flex flex-col text-slate-900 font-sans antialiased">
      <header className="bg-slate-900 text-white p-4 shadow-xl no-print sticky top-0 z-50 border-b border-indigo-500/30">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-lg rotate-2 transition-all hover:rotate-0">
              <FileType className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-black text-2xl tracking-tighter leading-none italic uppercase">Marlindo <span className="text-indigo-400 italic">Docs</span></h1>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.3em] mt-1">Smart Document Automator</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowHistory(true)}
              className="bg-slate-800 hover:bg-slate-700 px-4 py-2.5 rounded-xl border border-slate-700 transition-all flex items-center gap-3 text-xs font-black tracking-widest uppercase"
            >
              <History size={18} className="text-indigo-400"/>
              Riwayat ({history.length})
            </button>
            <div className="w-px h-8 bg-slate-700 mx-1"></div>
            <button 
              onClick={handleSave} 
              className={`px-6 py-2.5 rounded-xl flex items-center gap-2 font-black text-xs uppercase tracking-widest transition-all shadow-lg active:scale-95 ${saveStatus ? 'bg-emerald-500 text-white shadow-emerald-500/20' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-500/20'}`}
            >
              {saveStatus ? <CheckCircle2 size={18} /> : <Save size={18} />} 
              {saveStatus ? 'TERSESIMPAN' : (currentId ? 'UPDATE DATA' : 'SIMPAN NASABAH')}
            </button>
            <button 
              onClick={handleDownloadPdf} 
              disabled={isGenerating}
              className={`bg-orange-500 hover:bg-orange-400 px-6 py-2.5 rounded-xl flex items-center gap-3 font-black text-xs uppercase tracking-widest transition-all shadow-lg active:scale-95 text-white shadow-orange-500/20 ${isGenerating ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {isGenerating ? <Loader2 size={18} className="animate-spin" /> : <FileDown size={18} />} 
              {isGenerating ? 'GENERATING...' : 'DOWNLOAD PDF'}
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 flex flex-col lg:flex-row gap-6 h-[calc(100vh-88px)] overflow-hidden">
        
        <div className="w-full lg:w-1/3 space-y-6 no-print overflow-y-auto pr-3 custom-scrollbar pb-24">
          <div className="bg-white p-7 rounded-[2.5rem] shadow-sm border border-slate-200">
            <div className="flex justify-between items-center mb-8 border-b border-slate-100 pb-4">
              <h2 className="flex items-center gap-3 font-black text-slate-800 text-sm uppercase tracking-widest">
                <div className="w-2.5 h-7 bg-indigo-600 rounded-full"></div> 
                Data Nasabah
              </h2>
              <button onClick={handleReset} className="text-slate-300 hover:text-rose-500 transition-all p-2 hover:bg-rose-50 rounded-full">
                <RotateCcw size={18}/>
              </button>
            </div>
            
            <div className="grid gap-5">
              <FormInput label="Nama Lengkap (KTP)" value={state.applicant.fullName} onChange={(e) => updateApplicant('fullName', e.target.value)} placeholder="Masukkan nama sesuai identitas" />
              <div className="grid grid-cols-2 gap-4">
                <FormInput label="NIK / No. KTP" value={state.applicant.ktpNumber} onChange={(e) => updateApplicant('ktpNumber', e.target.value)} />
                <FormInput label="Nomor NPWP" value={state.applicant.npwpNumber} onChange={(e) => updateApplicant('npwpNumber', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormInput label="Tempat Lahir" value={state.applicant.pob} onChange={(e) => updateApplicant('pob', e.target.value)} />
                <FormInput label="Tanggal Lahir" type="date" value={state.applicant.dob} onChange={(e) => updateApplicant('dob', e.target.value)} />
              </div>
              <FormInput label="Alamat Domisili KTP" value={state.applicant.address} onChange={(e) => updateApplicant('address', e.target.value)} />
              <div className="grid grid-cols-2 gap-4">
                <FormInput label="No. WhatsApp" value={state.applicant.phone} onChange={(e) => updateApplicant('phone', e.target.value)} />
                <FormInput label="Rekening BTN" value={state.applicant.btnAccountNumber} onChange={(e) => updateApplicant('btnAccountNumber', e.target.value)} />
              </div>
            </div>
          </div>

          <div className="bg-white p-7 rounded-[2.5rem] shadow-sm border border-slate-200">
            <h2 className="flex items-center gap-3 font-black text-slate-800 mb-8 text-sm border-b border-slate-100 pb-4 uppercase tracking-widest">
              <div className="w-2.5 h-7 bg-emerald-500 rounded-full"></div> 
              Pekerjaan
            </h2>
            <div className="space-y-5">
              <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200 shadow-inner">
                <button onClick={() => updateApplicant('jobType', JobType.EMPLOYEE)} className={`flex-1 py-3 rounded-xl text-[11px] font-black transition-all ${state.applicant.jobType === JobType.EMPLOYEE ? 'bg-white text-indigo-700 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}>KARYAWAN</button>
                <button onClick={() => updateApplicant('jobType', JobType.ENTREPRENEUR)} className={`flex-1 py-3 rounded-xl text-[11px] font-black transition-all ${state.applicant.jobType === JobType.ENTREPRENEUR ? 'bg-white text-indigo-700 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}>WIRAUSAHA</button>
              </div>
              <FormInput label="Jabatan / Jenis Usaha" value={state.applicant.jobTitle} onChange={(e) => updateApplicant('jobTitle', e.target.value)} />
              <FormInput label="Gaji Bersih / Bulan (Rp)" type="number" value={state.applicant.monthlyIncome} onChange={(e) => updateApplicant('monthlyIncome', parseInt(e.target.value) || 0)} />
            </div>
          </div>

          <div className="bg-white p-7 rounded-[2.5rem] shadow-sm border border-slate-200">
            <h2 className="flex items-center gap-3 font-black text-slate-800 mb-8 text-sm border-b border-slate-100 pb-4 uppercase tracking-widest">
              <div className="w-2.5 h-7 bg-pink-500 rounded-full"></div> 
              Status Keluarga
            </h2>
            <div className="flex gap-4 mb-8">
              <button onClick={() => setState(s => ({...s, maritalStatus: MaritalStatus.SINGLE}))} className={`flex-1 py-3.5 rounded-2xl border-2 font-black text-[10px] transition-all uppercase tracking-widest ${state.maritalStatus === MaritalStatus.SINGLE ? 'bg-indigo-50 border-indigo-600 text-indigo-700' : 'bg-white border-slate-100 text-slate-400'}`}>BELUM KAWIN</button>
              <button onClick={() => setState(s => ({...s, maritalStatus: MaritalStatus.MARRIED}))} className={`flex-1 py-3.5 rounded-2xl border-2 font-black text-[10px] transition-all uppercase tracking-widest ${state.maritalStatus === MaritalStatus.MARRIED ? 'bg-indigo-50 border-indigo-600 text-indigo-700' : 'bg-white border-slate-100 text-slate-400'}`}>KAWIN</button>
            </div>
            {state.maritalStatus === MaritalStatus.MARRIED && (
              <div className="space-y-5 animate-in fade-in slide-in-from-top-4 duration-500">
                <FormInput label="Nama Pasangan" value={state.spouse?.fullName || ''} onChange={(e) => updateSpouse('fullName', e.target.value)} />
                <div className="grid grid-cols-2 gap-4">
                  <FormInput label="NIK Pasangan" value={state.spouse?.ktpNumber || ''} onChange={(e) => updateSpouse('ktpNumber', e.target.value)} />
                  <FormInput label="Pekerjaan" value={state.spouse?.job || ''} onChange={(e) => updateSpouse('job', e.target.value)} />
                </div>
              </div>
            )}
          </div>

          <div className="bg-white p-7 rounded-[2.5rem] shadow-sm border border-slate-200">
            <h2 className="flex items-center gap-3 font-black text-slate-800 mb-8 text-sm border-b border-slate-100 pb-4 uppercase tracking-widest">
              <div className="w-2.5 h-7 bg-orange-500 rounded-full"></div> 
              Unit Properti
            </h2>
            <div className="grid gap-5">
              <FormInput label="Proyek Perumahan" value={state.property.projectName} onChange={(e) => updateProperty('projectName', e.target.value)} />
              <div className="grid grid-cols-2 gap-4">
                <FormInput label="Kavling" value={state.property.kavlingNumber} onChange={(e) => updateProperty('kavlingNumber', e.target.value)} />
                <FormInput label="Luas Tanah" type="number" value={state.property.landSize} onChange={(e) => updateProperty('landSize', parseInt(e.target.value) || 0)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormInput label="Nomor Sertifikat (NIB)" value={state.property.nibNumber} onChange={(e) => updateProperty('nibNumber', e.target.value)} placeholder="Contoh: 19.01.06.12.00123" />
                <FormInput label="Tanggal Sertifikat" type="date" value={state.property.certificateDate} onChange={(e) => updateProperty('certificateDate', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormInput label="DP Lunas (Rp)" type="number" value={state.property.paidDP} onChange={(e) => updateProperty('paidDP', parseInt(e.target.value) || 0)} />
                <FormInput label="Sisa DP (Rp)" type="number" value={state.property.remainingDP} onChange={(e) => updateProperty('remainingDP', parseInt(e.target.value) || 0)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormInput label="Tenor KPR (Thn)" type="number" value={state.property.kprTerm} onChange={(e) => updateProperty('kprTerm', parseInt(e.target.value) || 0)} />
                <FormInput label="No. SPR" value={state.property.sprNumber} onChange={(e) => updateProperty('sprNumber', e.target.value)} />
              </div>
              <FormInput label="Tanggal Berkas" type="date" value={state.dateOfDocument} onChange={(e) => setState(s => ({...s, dateOfDocument: e.target.value}))} />
            </div>
          </div>
        </div>

        <div className="flex-1 bg-white/40 backdrop-blur-md overflow-hidden flex flex-col rounded-[3rem] shadow-inner no-print-bg border-4 border-white/80 relative">
          {isGenerating && (
            <div className="absolute inset-0 z-50 bg-indigo-900/40 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-300">
              <div className="bg-white p-8 rounded-[2rem] shadow-2xl flex flex-col items-center gap-4 border-4 border-indigo-500">
                <Loader2 size={48} className="text-indigo-600 animate-spin" />
                <div className="text-center">
                  <p className="font-black text-indigo-700 uppercase tracking-widest">Sedang Membuat PDF...</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">Jangan tutup halaman ini</p>
                </div>
              </div>
            </div>
          )}

          <div className="no-print p-6 bg-white/70 backdrop-blur-xl border-b border-slate-200/50 flex flex-col items-center gap-5 sticky top-0 z-40">
            {currentId && (
              <div className="text-[10px] font-black text-indigo-700 bg-white px-5 py-2 rounded-full border border-indigo-100 uppercase flex items-center gap-2 shadow-sm animate-in zoom-in-95 duration-300">
                <div className="w-2 h-2 bg-indigo-600 rounded-full animate-pulse shadow-[0_0_8px_rgba(79,70,229,0.5)]"></div>
                AKTIF: {state.applicant.fullName} | Kav {state.property.kavlingNumber}
              </div>
            )}
            <div className="flex bg-slate-900/10 p-1.5 rounded-2xl w-full max-w-lg shadow-inner">
              <button 
                onClick={() => setDocType('data-entry')}
                className={`flex-1 py-3 px-6 rounded-xl font-black text-[11px] transition-all flex items-center justify-center gap-3 uppercase tracking-widest ${state.documentType === 'data-entry' ? 'bg-white shadow-lg text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}
              >
                <FileText size={18}/> Data Entry
              </button>
              <button 
                onClick={() => setDocType('ajb-bank')}
                className={`flex-1 py-3 px-6 rounded-xl font-black text-[11px] transition-all flex items-center justify-center gap-3 uppercase tracking-widest ${state.documentType === 'ajb-bank' ? 'bg-white shadow-lg text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}
              >
                <LayoutGrid size={18}/> AJB Bank
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-12 flex flex-col items-center custom-scrollbar bg-slate-200">
            <div className="print-area flex flex-col items-center w-full max-w-[210mm]">
              {state.documentType === 'data-entry' ? (
                <>
                  <SPR_Official data={state} />
                  <div className="page-break"></div>
                  <IncomeStatementFixed data={state} />
                  <div className="page-break"></div>
                  <LampiranIII_Internal data={state} />
                  <div className="page-break"></div>
                  <ShortfallPaymentStatement data={state} />
                  <div className="page-break"></div>
                  <StandingInstructionDebitur data={state} />
                  <div className="page-break"></div>
                  <StandingInstructionDeveloper data={state} />
                  <div className="page-break"></div>
                  <LampiranXI_Internal data={state} />
                  <div className="page-break"></div>
                  <LampiranVI_External data={state} />
                  <div className="page-break"></div>
                  <HabitationStatement data={state} />
                  <div className="page-break"></div>
                  <DebetKuasa data={state} />
                  <div className="page-break"></div>
                  <PSUStatement data={state} />
                  <div className="page-break"></div>
                  <NoHouseStatement data={state} />
                  <div className="page-break"></div>
                  <NoJobStatement data={state} />
                  <div className="page-break"></div>
                  <LampiranVIII_External data={state} />
                </>
              ) : (
                <>
                  <AJBValidityStatement data={state} />
                  <div className="page-break"></div>
                  <CertificatePowerOfAttorney data={state} />
                  <div className="page-break"></div>
                  <SellAndVacatePowerOfAttorney data={state} />
                  <div className="page-break"></div>
                  <LandSizeStatement data={state} />
                </>
              )}
            </div>
          </div>
        </div>
      </main>

      {showHistory && (
        <div className="fixed inset-0 z-[100] bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[85vh] border-8 border-slate-200">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
              <div className="flex items-center gap-5">
                <div className="bg-indigo-600 p-3 rounded-2xl shadow-xl shadow-indigo-600/20">
                  <History className="text-white" size={28}/>
                </div>
                <div>
                  <h2 className="font-black text-2xl text-slate-900 tracking-tight">Database Berkas</h2>
                  <p className="text-xs font-black text-slate-400 uppercase tracking-widest mt-1">Daftar Nasabah Yang Tersimpan</p>
                </div>
              </div>
              <button onClick={() => setShowHistory(false)} className="bg-white hover:bg-slate-100 p-3 rounded-2xl transition-all border border-slate-200 shadow-sm active:scale-95">
                <X size={24}/>
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 space-y-4 custom-scrollbar">
              {history.length === 0 ? (
                <div className="text-center py-24">
                  <div className="bg-slate-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
                    <Search className="text-slate-300" size={40}/>
                  </div>
                  <p className="font-black text-slate-400 uppercase text-xs tracking-[0.3em]">Data Masih Kosong</p>
                </div>
              ) : (
                history.map((entry) => (
                  <div 
                    key={entry.id}
                    onClick={() => loadFromHistory(entry)}
                    className={`group relative p-6 rounded-[2rem] border-2 transition-all cursor-pointer flex justify-between items-center hover:shadow-2xl hover:-translate-y-1 ${currentId === entry.id ? 'bg-indigo-50 border-indigo-500/30' : 'bg-white border-slate-100 hover:border-indigo-400'}`}
                  >
                    <div className="flex items-center gap-6">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl shadow-inner ${currentId === entry.id ? 'bg-indigo-600 text-white shadow-indigo-600/20' : 'bg-slate-100 text-slate-400'}`}>
                        {entry.clientName.charAt(0)}
                      </div>
                      <div>
                        <div className="font-black text-slate-900 text-lg dareading-none mb-2">{entry.clientName}</div>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] font-black text-indigo-600 bg-white px-3 py-1 rounded-full border border-indigo-100 uppercase tracking-widest shadow-sm">{entry.unitInfo}</span>
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">• {entry.savedAt}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <button 
                        onClick={(e) => deleteHistory(entry.id, e)}
                        className="bg-slate-50 hover:bg-rose-500 text-slate-300 hover:text-white p-3 rounded-2xl transition-all border border-slate-100 hover:border-rose-500 shadow-sm"
                      >
                        <Trash2 size={20}/>
                      </button>
                      <ChevronRight size={28} className="text-slate-200 group-hover:text-indigo-600 transition-all translate-x-0 group-hover:translate-x-1"/>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="p-8 bg-slate-50 border-t border-slate-100 text-center">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em]">Sistem Otomasi Marlindo • 2025 Edition</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
