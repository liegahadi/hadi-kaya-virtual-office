
import React from 'react';
import { AppState } from '../../types';
import { COMPANY_INFO } from '../../constants';
import { formatCurrency, formatLongDate, numberToWords } from '../../utils/formatters';
import { DocumentLayout } from '../DocumentLayout';

export const Kwitansi: React.FC<{ data: AppState }> = ({ data }) => {
  const { applicant, property, dateOfDocument } = data;

  return (
    <DocumentLayout>
      <div className="border-4 border-double border-black p-8 relative">
        <div className="flex justify-between items-start mb-6">
          <div className="text-left">
            <h1 className="text-xl font-bold uppercase">{COMPANY_INFO.name}</h1>
            <p className="text-xs">Pangkalpinang</p>
          </div>
          <div className="text-right">
            <h2 className="text-2xl font-bold underline italic">KWITANSI</h2>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex border-b border-dotted border-black pb-1">
            <span className="w-48 italic">Telah terima dari</span>
            <span className="font-bold">: {applicant.fullName}</span>
          </div>
          <div className="flex border-b border-dotted border-black pb-1 bg-gray-50">
            <span className="w-48 italic">Uang Sebanyak</span>
            <span className="font-bold italic">: ### {numberToWords(property.downPayment)} Rupiah ###</span>
          </div>
          <div className="flex border-b border-dotted border-black pb-1">
            <span className="w-48 italic">Guna Pembayaran</span>
            <span className="flex-1">: Pembayaran Uang Muka (DP) Perumahan {property.projectName} - Unit {property.houseAddress}</span>
          </div>
        </div>

        <div className="mt-12 flex justify-between items-end">
          <div className="bg-gray-100 px-6 py-4 border-2 border-black">
            <span className="text-2xl font-bold">Terbilang Rp. {property.downPayment.toLocaleString('id-ID')}</span>
          </div>
          <div className="text-center w-64">
            <p>Pangkalpinang, {formatLongDate(dateOfDocument)}</p>
            <div className="h-20"></div>
            <p className="font-bold underline">{COMPANY_INFO.director}</p>
            <p className="text-xs">Direktur</p>
          </div>
        </div>

        <div className="mt-8 text-[10px] text-gray-500 italic">
          * Pembayaran dianggap sah apabila Cek/Giro telah diuangkan atau transfer telah masuk ke Rekening BTN {COMPANY_INFO.btnAccount} a/n {COMPANY_INFO.name}
        </div>
      </div>
    </DocumentLayout>
  );
};
