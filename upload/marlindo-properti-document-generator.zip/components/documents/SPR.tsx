
import React from 'react';
import { AppState } from '../../types';
import { COMPANY_INFO } from '../../constants';
import { formatCurrency, formatLongDate } from '../../utils/formatters';
import { DocumentLayout, DocHeader } from '../DocumentLayout';

export const SPR: React.FC<{ data: AppState }> = ({ data }) => {
  const { applicant, property, dateOfDocument } = data;

  return (
    <DocumentLayout>
      <DocHeader company={COMPANY_INFO.name} />
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold underline">SURAT PEMESANAN RUMAH (SPR)</h2>
      </div>

      <p className="mb-4">Yang bertanda tangan di bawah ini:</p>
      <table className="w-full mb-6">
        <tbody>
          <tr><td className="w-40">Nama Lengkap</td><td>: <strong>{applicant.fullName}</strong></td></tr>
          <tr><td>No. KTP</td><td>: {applicant.ktpNumber}</td></tr>
          <tr><td>Tempat/Tgl Lahir</td><td>: {applicant.pob}, {formatLongDate(applicant.dob)}</td></tr>
          <tr><td>Alamat</td><td>: {applicant.address}</td></tr>
          <tr><td>No. Telepon</td><td>: {applicant.phone}</td></tr>
          <tr><td>Pekerjaan</td><td>: {applicant.jobType}</td></tr>
        </tbody>
      </table>

      <p className="mb-4">Menyatakan setuju untuk memesan 1 (satu) unit rumah pada perumahan <strong>{property.projectName}</strong> dengan rincian sebagai berikut:</p>
      <table className="w-full mb-6 border-collapse">
        <tbody>
          <tr><td className="w-40 py-1 border-b">Lokasi / Alamat</td><td className="py-1 border-b">: {property.houseAddress}</td></tr>
          <tr><td className="py-1 border-b">Tipe / Luas Tanah</td><td className="py-1 border-b">: {property.houseSize} / {property.landSize} m2</td></tr>
          <tr><td className="py-1 border-b">Nomor NIB</td><td className="py-1 border-b">: {property.nibNumber}</td></tr>
          <tr><td className="py-1 border-b">Tgl Sertifikat</td><td className="py-1 border-b">: {formatLongDate(property.certificateDate)}</td></tr>
          <tr><td className="py-1 border-b">Harga Jual</td><td className="py-1 border-b">: {formatCurrency(property.price)}</td></tr>
          <tr><td className="py-1 border-b">Uang Muka (DP)</td><td className="py-1 border-b">: {formatCurrency(property.downPayment)}</td></tr>
          <tr><td className="py-1 border-b">Bank Pelaksana</td><td className="py-1 border-b">: {COMPANY_INFO.bankName}</td></tr>
        </tbody>
      </table>

      <p className="mb-8 text-justify">Demikian Surat Pemesanan Rumah ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya.</p>

      <div className="flex justify-between mt-12">
        <div className="text-center">
          <p>Pangkalpinang, {formatLongDate(dateOfDocument)}</p>
          <p className="mt-1">Pemesan,</p>
          <div className="h-20"></div>
          <p className="font-bold underline">{applicant.fullName}</p>
        </div>
        <div className="text-center">
          <p>Mengetahui,</p>
          <p className="mt-1">{COMPANY_INFO.name}</p>
          <div className="h-20"></div>
          <p className="font-bold underline">{COMPANY_INFO.director}</p>
          <p className="text-sm">Direktur</p>
        </div>
      </div>
    </DocumentLayout>
  );
};
