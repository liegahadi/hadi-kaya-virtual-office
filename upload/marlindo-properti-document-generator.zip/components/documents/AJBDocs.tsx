
import React from 'react';
import { AppState } from '../../types';
import { COMPANY_INFO } from '../../constants';
import { formatLongDate } from '../../utils/formatters';

const styles = {
  page: "a4-container text-[12pt] leading-snug text-black",
  times: { fontFamily: "'Times New Roman', Times, serif" },
  docTitle: "text-center font-bold underline text-[13pt] uppercase mb-1",
  docSubTitle: "text-center font-bold text-[13pt] uppercase mb-8",
  tableLabel: "w-[180px] align-top",
  tableColon: "w-[15px] align-top",
  signatureArea: "mt-16 flex justify-between",
  signatureBox: "text-center min-w-[220px]",
};

const PageWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className={`${styles.page} page-break`} style={styles.times}>
    {children}
  </div>
);

// 1. Surat Pernyataan Keabsahan Dokumen (AJB)
export const AJBValidityStatement: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle}>SURAT PERNYATAAN KEABSAHAN DOKUMEN</div>
    <div className={styles.docSubTitle}>(PROSES AKTA JUAL BELI)</div>
    <p className="mb-4">Saya yang bertanda tangan di bawah ini:</p>
    <table className="mb-6">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama Lengkap</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-4 leading-relaxed">
      Dengan ini menyatakan dengan sesungguhnya bahwa seluruh dokumen persyaratan administrasi yang saya serahkan kepada 
      <strong> {COMPANY_INFO.bankName}</strong> dan Notaris rekanan Bank dalam rangka proses Akta Jual Beli (AJB) atas unit rumah 
      di perumahan <strong>{data.property.projectName}</strong> Kavling <strong>{data.property.kavlingNumber}</strong> adalah 
      benar, asli, dan sah sesuai dengan aslinya.
    </p>
    <p className="text-justify mb-4 leading-relaxed">
      Apabila di kemudian hari ditemukan bahwa dokumen-dokumen tersebut tidak benar atau palsu, maka saya bersedia 
      bertanggung jawab sepenuhnya secara hukum baik pidana maupun perdata tanpa melibatkan pihak Bank maupun Pengembang.
    </p>
    <p className="mb-12">Demikian pernyataan ini dibuat untuk dipergunakan sebagaimana mestinya.</p>
    <div className="flex justify-end">
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p>Yang menyatakan,</p>
        <div className="h-28 flex items-center justify-center italic text-gray-400">Materai Rp10.000,-</div>
        <p className="font-bold underline uppercase">{data.applicant.fullName}</p>
      </div>
    </div>
  </PageWrapper>
);

// 2. Surat Kuasa Pengambilan Sertifikat
export const CertificatePowerOfAttorney: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle}>SURAT KUASA PENGAMBILAN SERTIFIKAT</div>
    <div className="h-12"></div>
    <p className="mb-4">Saya yang bertanda tangan di bawah ini:</p>
    <table className="mb-6">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat</td><td className={styles.tableColon}>:</td><td>{data.applicant.address}</td></tr>
      </tbody>
    </table>
    <p className="mb-4 font-bold">Memberikan KUASA sepenuhnya kepada:</p>
    <p className="mb-4 font-bold uppercase">{COMPANY_INFO.bankName}</p>
    <p className="text-justify mb-6 leading-relaxed">
      Untuk mengambil Sertifikat Hak Guna Bangunan (SHGB) / Sertifikat Hak Milik (SHM) asli atas nama saya 
      yang telah selesai diproses balik nama pada Kantor Pertanahan melalui Notaris/PPAT Rekanan Bank, 
      terhadap objek properti:
    </p>
    <table className="mb-8">
      <tbody>
        <tr><td className={styles.tableLabel}>Perumahan</td><td className={styles.tableColon}>:</td><td>{data.property.projectName}</td></tr>
        <tr><td className={styles.tableLabel}>No. Kavling</td><td className={styles.tableColon}>:</td><td>{data.property.kavlingNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Alamat Unit</td><td className={styles.tableColon}>:</td><td>{data.property.houseAddress}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-12 italic">
      Surat kuasa ini berlaku sejak ditandatangani dan tidak dapat ditarik kembali sampai dengan kewajiban 
      kredit saya pada Bank dinyatakan lunas.
    </p>
    <div className={styles.signatureArea}>
      <div className={styles.signatureBox}>
        <p>Penerima Kuasa,</p>
        <div className="h-24"></div>
        <p>(..........................................)</p>
        <p className="text-[10pt]">Pejabat Bank BTN</p>
      </div>
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p>Pemberi Kuasa,</p>
        <div className="h-24 flex items-center justify-center italic text-gray-400">Materai</div>
        <p className="font-bold underline uppercase">{data.applicant.fullName}</p>
      </div>
    </div>
  </PageWrapper>
);

// 3. Surat Kuasa Menjual & Mengosongkan
export const SellAndVacatePowerOfAttorney: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle}>SURAT KUASA MENJUAL DAN MENGOSONGKAN AGUNAN</div>
    <div className="h-8"></div>
    <p className="text-justify mb-4 leading-relaxed">
      Pemberi Kuasa dalam hal ini adalah DEBITUR pada <strong>{COMPANY_INFO.bankName}</strong> dengan data sebagai berikut:
    </p>
    <table className="mb-6">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>NIK</td><td className={styles.tableColon}>:</td><td>{data.applicant.ktpNumber}</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-4 leading-relaxed">
      Memberikan Kuasa kepada Bank untuk melakukan tindakan hukum berupa menjual agunan baik di bawah tangan 
      maupun melalui lelang, serta melakukan pengosongan terhadap objek agunan di <strong>{data.property.houseAddress}</strong> 
      apabila DEBITUR dinyatakan wanprestasi (cidera janji) dalam memenuhi kewajiban pembayaran angsuran KPR.
    </p>
    <p className="text-justify mb-4 leading-relaxed">
      Kuasa ini diberikan dengan hak substitusi dan merupakan bagian yang tidak terpisahkan dari Perjanjian Kredit 
      KPR Bersubsidi. Segala biaya yang timbul atas pelaksanaan kuasa ini menjadi tanggung jawab DEBITUR.
    </p>
    <p className="mb-12">Demikian surat kuasa ini dibuat dengan sebenar-benarnya untuk dipergunakan seperlunya.</p>
    <div className={styles.signatureArea}>
       <div className={styles.signatureBox}>
        <p>Menyetujui Suami/Istri,</p>
        <div className="h-24"></div>
        <p>(..........................................)</p>
      </div>
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p>Pemberi Kuasa,</p>
        <div className="h-24 flex items-center justify-center italic text-gray-400">Materai 10.000</div>
        <p className="font-bold underline uppercase">{data.applicant.fullName}</p>
      </div>
    </div>
  </PageWrapper>
);

// 4. Surat Pernyataan Luas Tanah (BPN)
export const LandSizeStatement: React.FC<{ data: AppState }> = ({ data }) => (
  <PageWrapper>
    <div className={styles.docTitle}>SURAT PERNYATAAN PERSETUJUAN LUAS TANAH</div>
    <div className="h-12"></div>
    <p className="mb-6">Yang bertanda tangan di bawah ini, saya selaku pembeli unit rumah:</p>
    <table className="mb-8">
      <tbody>
        <tr><td className={styles.tableLabel}>Nama</td><td className={styles.tableColon}>:</td><td>{data.applicant.fullName}</td></tr>
        <tr><td className={styles.tableLabel}>No. Kavling</td><td className={styles.tableColon}>:</td><td>{data.property.kavlingNumber}</td></tr>
        <tr><td className={styles.tableLabel}>Luas Tanah Pesanan</td><td className={styles.tableColon}>:</td><td>{data.property.landSize} m2</td></tr>
      </tbody>
    </table>
    <p className="text-justify mb-6 leading-relaxed">
      Menyatakan bersedia menerima dan menyetujui hasil pengukuran resmi dari Badan Pertanahan Nasional (BPN) 
      terhadap luas tanah tersebut di atas. Apabila terdapat selisih luas tanah (lebih atau kurang) antara 
      luas pesanan dengan hasil ukur BPN yang tertera pada Sertifikat, maka saya tidak akan melakukan tuntutan 
      apapun kepada <strong>{COMPANY_INFO.name}</strong>.
    </p>
    <p className="text-justify mb-12">
      Demikian surat pernyataan ini dibuat dengan penuh kesadaran dan tanpa paksaan dari pihak manapun.
    </p>
    <div className="flex justify-end">
      <div className={styles.signatureBox}>
        <p>{COMPANY_INFO.city}, {formatLongDate(data.dateOfDocument)}</p>
        <p>Yang menyatakan,</p>
        <div className="h-28 flex items-center justify-center italic text-gray-400">Materai</div>
        <p className="font-bold underline uppercase">{data.applicant.fullName}</p>
      </div>
    </div>
  </PageWrapper>
);
