
import React from 'react';

interface DocumentLayoutProps {
  children: React.ReactNode;
  id?: string;
  noHeader?: boolean;
}

export const DocumentLayout: React.FC<DocumentLayoutProps> = ({ children, id, noHeader }) => {
  return (
    <div id={id} className="a4-container page-break shadow-xl mb-8">
      <div className="content-area text-[11pt]">
        {children}
      </div>
    </div>
  );
};

export const DocHeader: React.FC<{ company: string, sub?: string }> = ({ company, sub }) => (
  <div className="text-center mb-6">
    <h1 className="text-2xl font-bold uppercase tracking-widest">{company}</h1>
    {sub && <p className="text-sm font-semibold uppercase">{sub}</p>}
    <div className="border-b-2 border-black mt-2 w-full"></div>
  </div>
);

export const SignatureBlock: React.FC<{ 
  location?: string, 
  date: string, 
  title?: string, 
  name: string, 
  subTitle?: string,
  materai?: boolean,
  align?: 'left' | 'right' | 'center' | 'between'
}> = ({ location = 'Pangkalpinang', date, title, name, subTitle, materai, align = 'right' }) => {
  
  const content = (
    <div className="text-center inline-block min-w-[200px]">
      <p>{location}, {date}</p>
      {title && <p className="mt-1">{title},</p>}
      <div className={`h-24 flex items-center justify-center italic text-xs text-gray-400`}>
        {materai && <div className="border border-gray-300 p-2 uppercase">Materai 10.000</div>}
      </div>
      <p className="font-bold underline uppercase">{name}</p>
      {subTitle && <p className="text-xs uppercase">{subTitle}</p>}
    </div>
  );

  if (align === 'between') return content;

  return (
    <div className={`flex mt-8 ${align === 'right' ? 'justify-end' : align === 'center' ? 'justify-center' : 'justify-start'}`}>
      {content}
    </div>
  );
};
